import { getApexMessage, reduceErrors } from 'c/salesforceApiUtils';
import { recordLog } from 'c/lwcLoggerUtils';
import { LightningElement } from 'lwc';
import getApiAuthentication from '@salesforce/apex/ObjectExplorerController.getApiAuthentication';
import getApiAuthenticationUrl from '@salesforce/apex/ObjectExplorerController.getApiAuthenticationUrl';
import revokeApiAuthentication from '@salesforce/apex/ObjectExplorerController.revokeApiAuthentication';
import { safeClientDiagnostic } from './objectExplorerLogic';
import locale from '@salesforce/i18n/locale';
import timeZone from '@salesforce/i18n/timeZone';
import hasModifyDataClassification from '@salesforce/userPermission/ModifyDataClassification';
import hasCustomizeApplication from '@salesforce/userPermission/CustomizeApplication';
import LightningConfirm from 'lightning/confirm';
import CsvExportModal from 'c/setupAuditTrailExportModal';
import getClassifyData from '@salesforce/apex/ObjectExplorerController.getClassifyData';
import saveClassifyData from '@salesforce/apex/ObjectExplorerController.saveClassifyData';
import searchClassifyOwners from '@salesforce/apex/ObjectExplorerController.searchClassifyOwners';
import resolveClassifyOwners from '@salesforce/apex/ObjectExplorerController.resolveClassifyOwners';
import searchObjects from '@salesforce/apex/ObjectExplorerController.searchObjects';
import getObjectInfo from '@salesforce/apex/ObjectExplorerController.getObjectInfo';
import getFieldAudit from '@salesforce/apex/ObjectExplorerController.getFieldAudit';
import { CLASSIFY_CSV_LIMITS, apiDiagnosticCode, classifySaveErrors, clientErrorDetails, classifyOwnerBatches, mergeClassifyOwners, csvFields, csvParts, csvFileName, readClassifyCsv, applyClassifyCsv, structureFieldView, fieldListView, classifySummary, visibleRelations, buildRelationBoard, classifyBatches, applyClassifyBatch, classifyFieldView, createClassifyEdits, classifyChanges, createOwnerOptions, classifyInput, objectOptionWindow, objectOptionScrollTop, objectOptionStart } from './objectExplorerLogic';

// 固定ヘッダー内で一度に表示する項目数
const FIELD_PAGE_SIZE = 400;

// 各グループの描画後に次の明細を作成し、取消済みのファイルは返さない。
function buildCsvBlob(groups, current, progress) {
    // 完了したグループのテキストだけを保持する。
    const parts = [];
    // 描画を挟むことで進捗の読み上げとキャンセル操作を受け付ける。
    function appendNext() {
        // キャンセル後は次のグループもファイルも作成しない。
        if (!current()) return undefined;
        // 次のグループを必要になった時点で整形する。
        const { value, done } = groups.next();
        // 全件を処理した場合だけブラウザへ渡せるファイルにする。
        if (done) return new Blob(parts, { type: 'text/plain' });
        // 見出しを含むCSVテキストを順番に保持する。
        parts.push(value.text);
        // 見出しを除いた累積明細数を通知する。
        progress(value.count);
        // 次の描画で出力の継続可否を再確認する。
        return new Promise(requestAnimationFrame).then(appendNext);
    }
    // 先頭の見出しから作成を開始する。
    return appendNext();
}

// 起点の探索と選択オブジェクトの詳細を制御
export default class ObjectExplorer extends LightningElement {
    // 認証を画面全体で共有し、秘密やトークンは保持しない
    apiAuthenticationStatus = 'CHECKING';
    // 確認失敗と未認証の公開案内を分けて表示
    apiAuthenticationMessage = '';
    // 標準APIから返された認証開始URLだけをリンクへ渡す
    apiAuthenticationUrl = '';
    // 認証要求の重複送信と古い応答の採用を防ぐ
    apiAuthenticationChecking = false;
    // 画面終了後や再確認前の応答を破棄する世代
    apiAuthenticationSequence = 0;
    // 初期状態の確認完了前に認証が必要な通信を始めない
    apiAuthenticationPromise;
    // 接続確認に成功するまでは認証をやり直す導線を表示する
    get apiAuthenticationRequired() { return !this.apiAuthenticationReady && !this.apiAuthenticationPending; }
    // 認証を確認できた場合だけ探索・分類の操作領域を描画する
    get apiAuthenticationReady() { return this.apiAuthenticationStatus === 'AUTHENTICATED'; }
    // 初期確認の間に未認証の操作領域を一瞬表示しない
    get apiAuthenticationPending() { return this.apiAuthenticationStatus === 'CHECKING' || (this.apiAuthenticationChecking && !this.apiAuthenticationReady); }
    get apiAuthenticationProgress() { return this.apiAuthenticationStatus === 'CHECKING' ? '認証状態を確認しています…' : '認証開始URLを取得しています…'; }
    // 状態確認中や保存中の再確認を抑止する
    get apiAuthenticationDisabled() { return this.apiAuthenticationChecking || this.busy || this.saving; }

    // 標準状態と実接続の結果を画面共通の案内へ反映する
    async refreshApiAuthentication() {
        // 終了した画面から認証確認を開始しない
        if (!this.componentConnected) return false;
        // 後続の要求から古いURLや案内が戻らないよう固定する
        const sequence = ++this.apiAuthenticationSequence;
        // 再確認が並行して走らないよう操作を固定する
        this.apiAuthenticationChecking = true;
        // 前の認証フロー用URLを再利用しない
        this.apiAuthenticationUrl = '';
        // 状態確認と開始URL取得の待機を合わせて30秒に制限する。
        let deadline;
        try {
            deadline = AbortSignal.timeout(30000);
            const timeout = new Promise((resolve, reject) => {
                deadline.onabort = () => reject(new Error('認証確認のタイムアウト'));
            });
            // 実行ユーザーの標準認証状態と同一組織への接続を確認する
            let state;
            try {
                state = await Promise.race([getApiAuthentication(), timeout]);
            } catch (error) {
                if (deadline.aborted) throw error;
                // 接続確認の失敗だけでは標準認証URLの取得を妨げない
                state = { status: 'UNAVAILABLE', message: 'Salesforce APIの認証状態を確認できませんでした。認証をやり直すか、接続設定と権限を確認してください。' };
            }
            // 接続終了や別要求より古い結果を画面へ出さない
            if (!this.componentConnected || sequence !== this.apiAuthenticationSequence) return false;
            // サーバーが公開した状態と案内だけを保持する
            this.apiAuthenticationStatus = state?.status || 'UNAVAILABLE';
            // 内部例外や資格情報ではなく公開メッセージを表示する
            this.apiAuthenticationMessage = state?.message || 'Salesforce APIの認証状態を確認できませんでした。認証をやり直すか、接続設定と権限を確認してください。';
            // 接続確認と独立して認証をやり直すURLを取得する
            if (!this.apiAuthenticationReady) {
                // 同じタブで標準OAuthへ移動するリンクを準備する
                const url = await Promise.race([getApiAuthenticationUrl(), timeout]);
                // 空のURLをクリック可能な認証操作とみなさない
                if (!url) throw new Error('認証開始URLを確認できません。');
                // 途中で別要求へ変わった場合はURLを破棄する
                if (this.componentConnected && sequence === this.apiAuthenticationSequence) this.apiAuthenticationUrl = url;
            }
            // 保存開始にも使うため、この要求で確認した結果を返す
            return this.apiAuthenticationReady;
        } catch (error) {
            // 古い要求の失敗で現在の認証を上書きしない
            if (this.componentConnected && sequence === this.apiAuthenticationSequence) {
                // 状態確認やURL取得の失敗を認証済み・未認証と推定しない
                // API応答本文やURLをエラーへ含めない
                const reason = this.apiAuthenticationStatus === 'UNAVAILABLE' ? this.apiAuthenticationMessage : '';
                if (deadline?.aborted) {
                    this.apiAuthenticationMessage = this.apiAuthenticationProgress + ' 30秒以内に応答がありませんでした。ページを再読み込みしてください。';
                    this.apiAuthenticationStatus = 'UNAVAILABLE';
                    return false;
                }
                const urlMessage = error?.body?.message?.startsWith('[OE-AUTH-URL]')
                    ? '認証開始 URL をこの組織の My Domain と照合できませんでした。'
                    : 'API認証を開始できませんでした。外部ログイン情報 InternalSalesforceApi と、そのプリンシパル SalesforceApiUserPrincipal の利用権限を確認してページを再読み込みしてください。';
                this.apiAuthenticationStatus = 'UNAVAILABLE';
                this.apiAuthenticationMessage = [reason, urlMessage].filter(Boolean).join(' ');
            }
            // 古い表示状態を確認成功として使わない
            return false;
        } finally {
            if (deadline) deadline.onabort = null;
            // 別要求の確認中表示を古い要求から解除しない
            if (sequence === this.apiAuthenticationSequence) this.apiAuthenticationChecking = false;
        }
    }
    // 本人の操作でだけ標準OAuth認証を開始する
    handleApiAuthenticationStart(event) {
        // 保存中や未準備のURLから認証を開始しない
        if (this.apiAuthenticationDisabled || !this.apiAuthenticationUrl) event.preventDefault();
    }
    // 本人が確認した場合だけこの機能のAPI認証を解除する
    async handleApiAuthenticationRevoke() {
        // 確認中・保存中・未認証の重複操作を受け付けない
        if (!this.apiAuthenticationReady || this.apiAuthenticationDisabled || this.saving) return;
        // 確認を表示している間も画面操作と二重実行を止める
        const version = this.connectionVersion;
        // 離脱時に確認待ちだけを解除可能にする。
        this.pendingInput = 'revoke';
        // 確認待ちの二重操作を止める。
        this.busy = true;
        // 確認画面の失敗と解除要求後の結果不明を区別する
        let submitted = false;
        // 削除APIの成否を内部情報を含めず公開する
        try {
            // 未保存入力がある場合は破棄されることを確認に含める
            const message = this.changeCount || this.hasInputErrors ? 'API認証を解除しますか？未保存のデータ分類の変更は失われます。' : 'この機能のAPI認証を解除しますか？';
            // 標準の確認ダイアログで本人の意思を確認する
            const confirmed = await LightningConfirm.open({ label: '認証解除', message, theme: 'warning' });
            // キャンセルや画面終了後は資格情報を変更しない
            if (!confirmed || version !== this.connectionVersion || !this.componentConnected) return;
            // ここから先の通信失敗では解除済みかどうかを断定しない
            submitted = true;
            // 実行ユーザー本人の固定した資格情報だけを解除する
            this.pendingInput = undefined;
            // 送信済みの解除と再接続後の状態取得の順序を固定する。
            this.revokePending = true;
            // 本人の資格情報だけを解除する。
            await revokeApiAuthentication();
            // 旧対象へ返る非同期応答を無効化する
            this.detailSequence += 1;
            // 分類の古い読取結果も破棄する
            this.classifySequence += 1;
            // 解除後は対象と未保存入力を残さず、認証前の画面へ戻す
            this.root = undefined;
            this.detail = undefined;
            this.classifyEdits = {};
            this.classifyData = {};
            this.classifyDataReady = false;
            // 変更件数と入力エラーを同じ時点でクリアする
            this.refreshClassifySummary();
            // 解除前の表示内容を操作できないよう先に非表示にする
            this.apiAuthenticationStatus = 'CHECKING';
            this.apiAuthenticationMessage = '';
            this.apiAuthenticationUrl = '';

        } catch (error) {
            // 通信失敗を解除成功とも解除失敗とも断定しない
            if (submitted) {
                // 状態が不明な間は操作領域を表示しない
                this.apiAuthenticationStatus = 'UNAVAILABLE';
                this.apiAuthenticationUrl = '';
                // 元の例外や資格情報を表示しない固定案内を使用する
                this.apiAuthenticationMessage = 'API認証の解除結果を確認できませんでした。画面を再読み込みして確認してください。';
            } else if (version === this.connectionVersion && this.componentConnected) {
                // 確認の失敗では認証状態や未保存入力を変更しない
                this.reportClientError(error, 'handleApiAuthenticationRevoke', 'confirmation');
            }
            // 結果不明や確認失敗では自動で認証確認を再送しない。
            return;
        } finally {
            // キャンセルや例外でも操作中状態を解除する
            if (submitted || version === this.connectionVersion) {
                // 現在の確認または送信済みの要求だけがロックを解放する。
                this.pendingInput = undefined;
                // ロック解除後は接続時の認証確認を許可する。
                this.revokePending = false;
                // 新しい操作を受け付ける。
                this.busy = false;
            }
        }
        // 解除が完了してから現在の接続で認証状態を再確認する。
        if (this.componentConnected) this.apiAuthenticationPromise = this.refreshApiAuthentication();
    }
    // エラー時だけ処理場所を表示し、通常の操作では診断表示を出さない
    clientError;
    // 捕捉した例外をコンポーネント内の案内と安全なコンソール情報へ変換
    reportClientError(error, operation, phase, message = '', code = '') {
        // 処理位置と種類に、呼出元で指定した公開可能な理由を添付
        const apiCode = apiDiagnosticCode(message);
        // JSは固定理由を使用し、APIの公開理由と混同しない
        const diagnostic = safeClientDiagnostic(code || 'OE-JS-UNEXPECTED');
        // APIコードがある場合も本文を診断ログへ含めない
        const details = { ...clientErrorDetails(error, operation, phase), code: apiCode || (error?.body ? 'OE-API-UNCLASSIFIED' : diagnostic.code), message: message || diagnostic.reason };
        // 記録の重複だけ共通処理で抑止し、表示状態は画面側で更新
        if (!recordLog(this.clientError, details, 'ObjectExplorer')) return;
        // 同じ画面の診断表示へ新しい記録を反映
        this.clientError = details;
    }
    // 子コンポーネントの描画・宣言的イベントで起きた例外を画面内へ収める
    errorCallback(error) {
        // 自分自身のイベント処理は各入口のtry/catchで別途捕捉
        this.reportClientError(error, 'errorCallback', 'child-component');
    }
    // DOMプロパティの公開範囲に依存せず画面の接続状態を管理
    componentConnected = false;
    // 確認・取込中の離脱では、その操作が保持するロックだけを解放する。
    pendingInput;
    // 解除を送信した後は結果の確定まで再接続時の認証確認を待つ。
    revokePending = false;
    // 確認と分割保存を開始した画面接続を識別する
    connectionVersion = 0;
    // LWCの標準ライフサイクルで画面の利用開始を記録
    connectedCallback() {
        // 画面が有効な間だけ保存確認や非同期応答を受け付ける
        this.componentConnected = true;
        // 初回は認証状態を確認し、未選択のオブジェクトを自動選択しない
        if (!this.revokePending) this.apiAuthenticationPromise = this.refreshApiAuthentication();
    }
    // 初期状態は参照専用
    mode = 'reference';
    // オブジェクト選択を共用する二つの作業モード
    modeOptions = [{ label: 'オブジェクト構造', value: 'reference' }, { label: 'データ分類設定', value: 'classify' }];
    // 編集変更時だけ算出する件数を保持
    changeCount = 0;
    // 確定できない入力がある間は保存を許可しない
    inputErrorCount = 0;
    // 項目定義と検索条件に対応する整列済み一覧を保持
    fieldView;
    // 構造の日時・ユーザー名は条件変更時だけ整形して保持
    structureView;
    // 分類の元データを項目API名で保持
    classifyData = {};
    // ページや検索条件を変えても編集値を保持
    classifyState = {};
    // 分類の表示モデルは現在のページに限定して保持
    classifyView;
    // 分類候補は組織の定義から取得
    classifyOptions = { ComplianceGroup: [], SecurityClassification: [], BusinessStatus: [] };
    // 未取得や失敗時は分類を編集できないようにする
    classifyDataReady = false;
    // 保存処理中は編集と画面遷移を固定
    saving = false;
    // 確認ダイアログとは分離して実際の保存中だけ固定表示
    saveInProgress = false;
    // 保存要求ごとの確認済み成功数
    saveSuccessCount = 0;
    // 保存要求ごとの確認済み失敗数
    saveFailureCount = 0;
    // 処理結果と進捗の案内
    classifyNotice = '';
    classifyNoticeIsError = false;

    // 進捗・成功とエラーを、文言に依存せず表示し分ける。
    setClassifyNotice(message, isError = false) {
        this.classifyNotice = message;
        this.classifyNoticeIsError = isError;
    }
    // CSVの検証エラーは既存の編集値と分けて保持
    csvErrors = [];
    // 古い分類読取の反映を抑止
    classifySequence = 0;
    // 古い所有者検索の反映を抑止
    ownerSequence = 0;
    // 必須の起点と詳細を別々に保持
    root;
    // 下部で表示する選択先の詳細
    detail;
    // 同じ相手でも参照方向ごとに選択を区別
    selectedKey = 'root';
    // 起点が変わるまで整列済みの関連を共有
    relations = [];
    // 関連の再生成が必要な起点の参照を保持
    relationSource;
    // 参照元は初期表示で単一参照先の通常項目だけにする
    incomingKind = 'standard';
    incomingKindOptions = [{ label: '通常の参照', value: 'standard' }, { label: '多態参照', value: 'polymorphic' }];
    // 対象が同じでも参照の種類が変わった場合は関連を再生成
    incomingKindSource;
    // 方向別の全カードを保持
    board = { incoming: [], outgoing: [] };
    incomingTerm = '';
    outgoingTerm = '';
    // 検索結果を標準候補UIへ渡す
    objectOptions = [];
    // オブジェクト検索語を保持
    objectTerm = '';
    // 入力欄の候補を開閉
    candidatesOpen = false;
    // 候補の強調位置を入力フォーカスと分離
    activeCandidateIndex = -1;
    // 候補全体のスクロール位置から描画する範囲を決定
    candidateScrollTop = 0;
    // 候補の自然な行高を仮想表示とキー移動で共有
    candidateRowHeight = 0;
    // 候補の余白と行のモデルを入力変更時だけ生成
    candidateView = objectOptionWindow([], -1, 0);
    // 候補取得中と該当なしを区別
    candidatesBusy = false;
    // 候補取得のエラーを構造取得のエラーから独立して管理
    candidateError;
    // 項目ラベルとAPI名に共通の検索語を保持
    fieldSearch = '';
    // 新しい選択の一覧を描画後に案内
    revealFields = false;
    // データ型の初期値はすべて
    fieldType = '';
    // 項目のページ位置を保持
    fieldPage = 1;
    // 通信中は起点変更の二重実行を抑止
    busy = false;
    // 起点の取得中だけ古い関連図を非表示にする
    rootLoading = false;
    // 読み取り失敗を画面へ通知
    error = '';
    // 古い検索応答の上書きを防止
    searchSequence = 0;
    // 古い詳細応答の上書きを防止
    detailSequence = 0;
    // 絞り込み結果を保持し、ページ移動時の全件再計算を避ける
    filtered = [];
    // データ型の候補を項目取得時に生成
    typeOptions = [{ label: 'すべてのデータ型', value: '' }];
    // 画面幅の変化を監視し、配置だけを更新する
    resizeObserver;
    // 標準APIを利用できない環境だけウィンドウの幅変更を監視
    resizeFallbackAttached = false;
    // 解除時も同じ関数を指定できるようにイベントハンドラーを保持
    handleViewportResize = () => {
        // 画面外の要素を参照せず、現在の表示領域だけを測定
        try { this.syncViewportLayout(this.template.querySelector('.c-viewport')?.clientWidth); }
        catch (error) { this.reportClientError(error, 'handleViewportResize', 'layout'); }
    };
    // 実際の表示領域に合わせて左右の列数を切り替える
    narrowRelations = false;
    // カード内容と検索条件が同じ場合は全カードの再測定を省く
    cardHeightSource;
    // 最後に測定した表示幅を保持
    cardHeightWidth;
    // 描画後に表示領域のサイズ変更を監視
    renderedCallback() {
        // 画面イベントの例外をコンポーネント外へ伝播させない
        try {
            // 選択先の一覧がDOMへ反映された後に移動
            if (this.revealFields && this.detail) {
                // 再描画のたびに画面を移動しない
                this.revealFields = false;
                // キーボード操作の続きも一覧から行えるようにする
                const heading = this.template.querySelector('.c-detail-title');
                // 非同期取得後の最新オブジェクト見出しへ案内
                heading?.focus({ preventScroll: true });
                // 図の下にある項目一覧を確実に見える位置へ置く
                heading?.scrollIntoView({ behavior: 'smooth', block: 'start' });
            }
            // 分類モードや起点取得中は表示幅の監視を解除
            if (!this.isReference || this.rootLoading) { this.stopViewportObservation(); return; }
            // 描画されていない表示領域へ監視を登録しない
            const viewport = this.template.querySelector('.c-viewport');
            // 対象解除でDOMが消えた場合も以前の監視を残さない
            if (!viewport) { this.stopViewportObservation(); return; }
            // 再描画でも現在の表示幅とカード内容を反映
            this.syncViewportLayout(viewport.clientWidth);
            // 同じ表示領域へ監視を重複登録しない
            if (this.resizeObserver || this.resizeFallbackAttached) { return; }
            // 対応環境では要素単位のサイズ変更を監視
            if (typeof ResizeObserver === 'function') {
                // 生成できてもDOMの監視を拒否される場合があるため登録まで確認
                let observer;
                try {
                    // 初回通知と幅変更を再描画と同じレイアウト処理へ渡す
                    observer = new ResizeObserver((entries) => {
                        // 解除済みの監視から届く通知で新しい画面を更新しない
                        if (this.resizeObserver !== observer) { return; }
                        // 通知に含まれる現在の表示幅を反映
                        try { this.syncViewportLayout(entries[0]?.contentRect.width); }
                        catch (error) { this.reportClientError(error, 'renderedCallback', 'resize-observer'); }
                    });
                    // 現在のDOMへ登録できた監視だけを保持
                    observer.observe(viewport);
                    // 生成だけ成功した状態を登録済みとして扱わない
                    this.resizeObserver = observer;
                    // ウィンドウ監視との重複登録を避ける
                    return;
                } catch (error) {
                    // 登録に失敗した監視を解放してから代替処理へ進む
                    try { observer?.disconnect(); }
                    catch (cleanupError) { this.reportClientError(cleanupError, 'renderedCallback', 'resize-observer-cleanup'); }
                    // 利用不可の既知例外は代替処理で回復し、その他は位置を通知
                    if (!['TypeError', 'NotSupportedError', 'SecurityError'].includes(error?.name)) {
                        this.reportClientError(error, 'renderedCallback', 'resize-observer');
                    }
                }
            }
            // 標準APIを利用できない環境ではウィンドウの幅変更を検知
            window.addEventListener('resize', this.handleViewportResize);
            // 再描画によるイベントの重複登録を防止
            this.resizeFallbackAttached = true;

        } catch (error) {
            // 処理名を付けてこの画面内へエラーを表示
            this.reportClientError(error, 'renderedCallback', 'layout');
        }
    }
    // 表示幅に応じた列数とカード高さを同期
    syncViewportLayout(width) {
        // 非表示や未測定の幅でレイアウトを切り替えない
        const narrow = width > 0 ? width < 1152 : this.narrowRelations;
        // 列数を変える場合は再描画後のDOMで高さを測定
        if (this.narrowRelations !== narrow) {
            // 列幅の異なる測定結果を再利用しない
            this.cardHeightSource = undefined;
            // 列数変更を描画へ反映
            this.narrowRelations = narrow;
            // 次の描画完了後にカード高さを測定
            return;
        }
        // 列数が変わらない幅変更と内容変更も高さへ反映
        this.syncCardHeights();
    }
    // モード切り替えと画面破棄で両方の監視方式を解除
    stopViewportObservation() {
        // 対応環境の要素監視を解除
        this.resizeObserver?.disconnect();
        // 次の表示では新しいDOMへ登録し直す
        this.resizeObserver = undefined;
        // 非対応環境のウィンドウ監視を解除
        if (this.resizeFallbackAttached) { window.removeEventListener('resize', this.handleViewportResize); }
        // 同じコンポーネントの再表示時に監視を再登録できる状態へ戻す
        this.resizeFallbackAttached = false;
    }
    // 全カードの自然な高さを測り、最大値へ統一
    syncCardHeights() {
        // 項目一覧の入力やページ変更ではカードの高さを再計算しない
        const width = this.template.querySelector('.c-viewport')?.clientWidth;
        // 選択のハイライトは自然な高さを変えないため再測定しない
        const source = this.cardHeightSource;
        // 内容・表示条件・幅が変わった場合だけ共通高さを更新
        if (source?.root === this.root && source?.relations === this.relations && source?.incomingTerm === this.incomingTerm && source?.outgoingTerm === this.outgoingTerm && this.cardHeightWidth === width) { return; }
        // 検索結果に含まれる左右のカードと起点を同じ基準で測る
        const cards = [...this.template.querySelectorAll('.c-node')];
        // 前回の固定値を外し、画面幅や検索結果に応じた自然な高さへ戻す
        cards.forEach((card) => { card.style.height = ''; });
        // 全件の読み取りをまとめ、測定中の書き込みを避ける
        const height = Math.ceil(Math.max(0, ...cards.map((card) => card.getBoundingClientRect().height)));
        // 全行と一行分の余白を収める最大の高さに揃える
        cards.forEach((card) => { card.style.height = `${height}px`; });
        // ハイライトを除いた表示内容の依存元を保持
        this.cardHeightSource = { root: this.root, relations: this.relations, incomingTerm: this.incomingTerm, outgoingTerm: this.outgoingTerm };
        // 同じカードでも幅が変われば再測定
        this.cardHeightWidth = width;
    }
    // 画面を離れた後に監視を残さない
    disconnectedCallback() {
        // 画面イベントの例外をコンポーネント外へ伝播させない
        try {
            // 確認待ちや非同期応答が残っていても終了済み画面では保存しない
            this.componentConnected = false;
            // 前の画面で開始した出力は再接続しても保存しない。
            this.exportController?.abort();
            // 再接続後の新しい出力を許可する。
            this.exportController = undefined;
            // 保存に使用した一時URLを解放する。
            this.releaseDownload();
            // 復帰後も離脱前の確認・認証待ち・保存応答を無効にする
            this.connectionVersion += 1;
            // 確認待ち・CSV読取中の画面ロックを次の接続へ持ち越さない。
            if (this.pendingInput) {
                // 前の取込進捗を終了し、未保存入力は維持する。
                if (this.pendingInput === 'import') this.setClassifyNotice('');
                // 新しい確認・取込を開始できる状態へ戻す。
                this.pendingInput = undefined;
                // 保存など他の操作が所有するロックには触れない。
                this.busy = false;
            }
            // 送信済みの解除に先行して認証済み画面を再表示しない。
            if (this.revokePending) this.apiAuthenticationStatus = 'CHECKING';
            // 古い保存が復帰後の操作をロックし続けないよう終了する
            if (this.saving) {
                // 送信済み要求は完了し得るため、古い分類を保存基準にしない
                if (this.saveInProgress) {
                    // 最新状態を取得するまで再保存を拒否する
                    this.classifyDataReady = false;
                    // 停止した後続処理と送信済み処理の結果を区別する
                    this.setClassifyNotice('画面を離れたため後続の保存を中断しました。送信済みの保存は完了する場合があります。対象を選択し直して最新状態を確認してください。');
                } else {
                    // 離脱前の確認を再利用せず、本人の新しい操作を待つ
                    this.setClassifyNotice('保存確認を中断しました。保存は実行していません。');
                }
                // 復帰後の新しい確認を受け付ける
                this.saving = false;
                // 古い処理の固定スピナーを残さない
                this.saveInProgress = false;
                // 対象の再選択を可能にする
                this.busy = false;
            }
            // 破棄済み画面へ認証状態を反映しない
            this.apiAuthenticationSequence += 1;
            // DOMが破棄された後へサイズ変更の通知を残さない
            this.stopViewportObservation();

        } catch (error) {
            // 処理名を付けてこの画面内へエラーを表示
            this.reportClientError(error, 'disconnectedCallback', 'ui-event');
        }
    }
    // 方向別のカードモデルを検索条件と選択状態へ同期
    layoutBoard() {
        this.board = this.root ? buildRelationBoard(this.root, this.relations, this.selectedKey, this.incomingTerm, this.outgoingTerm)
            : { incoming: [], outgoing: [] };
    }
    // 検索は左右それぞれに適用し、項目一覧の選択を変更しない
    handleRelationFilter(event) {
        // 画面イベントの例外をコンポーネント外へ伝播させない
        try {
            if (event.target.name === 'incoming') { this.incomingTerm = event.target.value; }
            else { this.outgoingTerm = event.target.value; }
            this.layoutBoard();

        } catch (error) {
            // 処理名を付けてこの画面内へエラーを表示
            this.reportClientError(error, 'handleRelationFilter', 'ui-event');
        }
    }
    // 起点変更を一つの通信単位で管理
    async loadRoot(name, revealDetail = true) {
        // 対象を取得し直すときは以前のエラー位置を消す
        this.clientError = undefined;
        // 未指定の起点や通信中の重複変更を拒否
        if (!name || this.busy) { return; }
        // オブジェクト変更前に未保存の編集を確認
        if (!(await this.confirmDiscard())) { return; }
        // 初期表示以外では取得完了後に項目一覧へ案内
        const revealFields = Boolean(this.root) && revealDetail;
        // 図と詳細の更新中を表示
        this.busy = true;
        // 古い図を外して起点の取得を案内
        this.rootLoading = true;
        // 古いエラーを解除
        this.error = '';
        // 遅延した詳細取得を無効化
        this.detailSequence += 1;
        // 前の対象の分類読取も破棄
        this.classifySequence += 1;
        // 古い検索応答と候補リストを閉じる
        this.closeCandidates();
        // 変更前の対象と項目一覧を読み込み開始時にクリア
        this.root = undefined;
        // 古い項目や関連情報を残さない
        this.detail = undefined;
        // 古いカードを表示データからも除去
        this.board = { incoming: [], outgoing: [] };
        this.incomingTerm = '';
        this.outgoingTerm = '';
        // 適用前の対象名を入力に残さない
        this.objectTerm = '';
        // 旧対象の候補を選択できない状態にする
        this.options = [];
        // 次の取得成功まで分類を未取得として扱う
        this.classifyData = {};
        // 新しい対象の分類を取得するまで編集させない
        this.classifyDataReady = false;
        // 前の対象の処理結果を持ち越さない
        this.setClassifyNotice('');
        // 前の対象のCSVエラーを持ち越さない
        this.csvErrors = [];
        // 古い関連と派生一覧・件数・型候補をクリア
        this.rebuild();
        // 読み取り結果で画面全体を更新
        try {
            // 起点に必要な構造を取得
            const data = await this.readObjectInfo(name);
            // 初期読み込み以外では選択先の項目一覧を表示
            this.revealFields = revealFields;
            // 新しい起点を保持
            this.root = data;
            // 起点を最初の選択カードにする
            this.detail = data;
            // 起点の選択状態を新しい図へ合わせる
            this.selectedKey = 'root';
            // 起点変更前の検索応答を無効化
            this.searchSequence += 1;
            // 選択後は候補を閉じる
            this.candidatesOpen = false;
            // 破棄した候補要求の読み込み表示も解除
            this.candidatesBusy = false;
            // 起点変更で検索とページ位置をリセット
            this.fieldSearch = '';

            // 新しいオブジェクトのすべての型を表示
            this.fieldType = '';
            // 項目一覧を先頭へ戻す
            this.fieldPage = 1;
            // 関連カードと項目一覧を再構築
            this.rebuild();
            // 分類モードでは選択先の分類も取得
            if (!this.isReference) { await this.loadClassifyData(); }
        } catch (error) {
            // 取得失敗の処理場所をこの画面内へ表示
            this.reportClientError(error, 'loadRoot', 'object-info');
            // Apexの公開メッセージだけを表示
            this.error = getApexMessage(error, 'オブジェクト構造を取得できませんでした。');
        } finally {
            // 成功・失敗のどちらでも確定した図の表示へ戻す
            this.rootLoading = false;
            // 次の探索操作を許可
            this.busy = false;
        }
    }
    // 構造モードだけで項目定義の作成・更新情報を取得
    async readObjectInfo(name, scope = this.mode) {
        // 構造と参照可否を従来の取得元で確定
        const data = await getObjectInfo({ objectName: name, mode: scope });
        // 分類モードと可視カスタム項目がない場合は日時取得のApex要求を省略
        if (!this.isReference || !data.fields.some((field) => field.custom)) { return data; }
        // 初期状態の確認結果を待ち、未認証で既知のAPI失敗を起こさない
        await this.apiAuthenticationPromise;
        // 権限不足・確認不能も共通案内へまとめ、構造の閲覧は維持する
        if (this.apiAuthenticationStatus !== 'AUTHENTICATED') return data;
        // API取得とJSでの表示データ加工の失敗を混同しない
        let audit;
        try {
            // 日時とユーザー名は項目API名に対応する同じ応答から取得
            audit = await getFieldAudit({ objectName: data.apiName });
        } catch (error) {
            // 認証・監査情報の取得箇所を識別
            const message = getApexMessage(error, '項目の作成・更新情報を取得できませんでした。API連携設定と権限を確認してください。');
            // 項目一覧を開いていなくても安全な失敗理由を表示
            this.reportClientError(error, 'readObjectInfo', 'field-audit', message);
            // 構造の閲覧は継続し、情報未取得を成功と見せない
            return { ...data, auditNotice: message };
        }
        try {
            // 失敗理由を推測せず、必要なAPI応答の型を使用直前に検証する
            if (audit === null || typeof audit !== 'object' || Array.isArray(audit)) {
                this.reportClientError(new TypeError(), 'readObjectInfo', 'field-audit-view', safeClientDiagnostic('OE-JS-AUDIT-DATA').reason, 'OE-JS-AUDIT-DATA');
                return { ...data, auditNotice: safeClientDiagnostic('OE-JS-AUDIT-DATA').reason };
            }
            // 表示対象の項目へだけ取得値を合成するJS処理
            return { ...data, fields: data.fields.map((field) => ({ ...field, ...(Object.prototype.hasOwnProperty.call(audit, field.apiName) ? audit[field.apiName] : {}) })) };
        } catch (error) {
            // API認証が失敗したと誤認させず表示データ加工の失敗として通知
            const message = '項目の作成・更新情報を表示用に組み立てられませんでした。';
            // JS側の例外種別と処理位置を表示し、構造の閲覧は継続
            this.reportClientError(error, 'readObjectInfo', 'field-audit-view', message, 'OE-JS-AUDIT-VIEW');
            // 不完全な日時情報を正常な取得結果として扱わない
            return { ...data, auditNotice: message };
        }
    }
    // 項目の日時取得に失敗した場合だけ構造一覧へ案内
    get auditNotice() { return this.isReference ? this.detail?.auditNotice : ''; }
    // 選択と関連フィルターを図へ反映
    rebuild() {
        // 起点が変わった場合だけ関連を生成
        this.refreshRelations();
        // 詳細の取得・選択変更に合わせて一覧を一度だけ更新
        this.refreshFields();
        // 起点取得後だけ描画モデルを生成
        this.layoutBoard();
    }
    // 図の初期候補と関連一覧で同じ整列済みデータを共有
    refreshRelations() {
        // ページやカードの選択だけでは関連を変換し直さない
        if (this.relationSource === this.root && this.incomingKindSource === this.incomingKind) { return; }
        // 図と一覧の関係候補を同じ配列へ確定
        this.relations = visibleRelations(this.root, this.incomingKind);
        // 対象やモード切り替えを同じ起点参照で判定
        this.relationSource = this.root;
        this.incomingKindSource = this.incomingKind;
    }
    // 入力値で候補を検索
    async handleSearch(event) {
        // 画面イベントの例外をコンポーネント外へ伝播させない
        try {
            // 入力語を保持し、起点の選択は候補の確定まで変えない
            if (this.root || this.busy) { return; }
            // 検索語は未選択時の入力だけから受け取る
            this.objectTerm = event.detail.value;
            // 検索条件に合う候補を開く
            await this.searchCandidates();

        } catch (error) {
            // 処理名を付けてこの画面内へエラーを表示
            this.reportClientError(error, 'handleSearch', 'ui-event');
        }
    }
    // 未選択の入力を明示的にクリックした場合だけ空欄候補も開く
    async handleSearchClick() {
        // 画面イベントの例外をコンポーネント外へ伝播させない
        try {
            // 現在の起点を変更せず候補を探せるようにする
            if (this.root || this.busy || this.candidatesOpen) { return; }
            // クリックは全候補の表示を明示した操作として扱う
            await this.searchCandidates(true);

        } catch (error) {
            // 処理名を付けてこの画面内へエラーを表示
            this.reportClientError(error, 'handleSearchClick', 'ui-event');
        }
    }
    // 入力フォーカスを残してSLDS候補の移動・確定を制御
    async handleSearchKey(event) {
        // 画面イベントの例外をコンポーネント外へ伝播させない
        try {
            // IME変換中や読み込み中の操作で選択を確定しない
            if (this.root || event.detail.isComposing || this.busy) { return; }
            // Escapeは候補だけを閉じる
            if (event.detail.key === 'Escape') {  this.closeCandidates(); return; }
            // 閉じた候補は矢印操作で取得
            if (!this.candidatesOpen && ['ArrowDown', 'ArrowUp'].includes(event.detail.key)) { await this.searchCandidates(); return; }
            // 未取得の候補へ位置を対応づけない
            if (!this.candidatesOpen || !this.options.length) { return; }
            // Enterでは強調した候補、または唯一の候補だけを選択
            if (event.detail.key === 'Enter') {
                // 選択対象を現在の候補配列から特定
                const option = this.options[this.activeCandidateIndex] || (this.options.length === 1 ? this.options[0] : undefined);
                // 未選択の複数候補は推測せず入力を維持
                if (!option) { return; }
                // 入力の送信より候補確定を優先

                // 候補のAPI名で起点を変更
                await this.loadRoot(option.value);
                // 他のキー処理を続けない
                return;
            }
            // 矢印以外は通常の入力操作へ委ねる
            if (!['ArrowDown', 'ArrowUp'].includes(event.detail.key)) { return; }
            // スクロールの代わりに候補を強調

            // 上方向の初回操作は末尾、下方向は先頭へ移動
            const step = event.detail.key === 'ArrowDown' ? 1 : -1;
            // 候補配列の範囲内で循環
            this.activeCandidateIndex = this.activeCandidateIndex < 0 ? (step > 0 ? 0 : this.options.length - 1) : (this.activeCandidateIndex + step + this.options.length) % this.options.length;
            // 現在の表示枠に合わせ、末尾への移動でも全件を描画しない
            // DOMの座標計算を候補の純粋な変換処理から分離
            this.candidateScrollTop = objectOptionScrollTop(this.activeCandidateIndex, event.detail.scrollTop ?? this.candidateScrollTop, event.detail.height || 280, this.candidateRowHeight);
            // 行と上下余白を一つのモデルへ確定
            this.refreshCandidateWindow();

        } catch (error) {
            // 処理名を付けてこの画面内へエラーを表示
            this.reportClientError(error, 'handleSearchKey', 'ui-event');
        }
    }
    // スクロールに合わせて表示位置付近の候補だけを描画
    handleCandidateScroll(event) {
        // 画面イベントの例外をコンポーネント外へ伝播させない
        try {
            // 通常スクロールでもキーボード移動でも同じ座標を保持
            const top = event.detail.top;
            // 初回の行高計測も同じ表示モデルへ反映
            const rowHeight = event.detail.rowHeight ?? this.candidateRowHeight;
            // 行高が変わった時は同じスクロール位置でも余白を再計算
            const heightChanged = rowHeight !== this.candidateRowHeight;
            // 同じ位置と行高の通知では再描画しない
            if (top === this.candidateScrollTop && !heightChanged) { return; }
            // 描画範囲内でも表示枠から外れた候補は確定対象から外す
            const active = this.activeCandidateIndex;
            // ブラウザのスクロール丸めによる1px未満の差で強調を解除しない
            const selectedVisible = active >= 0 && Math.abs(objectOptionScrollTop(active, top, event.detail.height || 280, rowHeight) - top) < 1;
            // 実際に表示枠を離れた候補だけを解除
            const nextActive = selectedVisible ? active : -1;
            // 更新不要な描画でも現在の座標と実測高は保持
            this.candidateScrollTop = top;
            // 表示行と上下余白で同じ行高を使用
            this.candidateRowHeight = rowHeight;
            // 候補行を作り直す前に範囲の変更を確認
            const start = objectOptionStart(this.options.length, top, rowHeight);
            // 同じ候補範囲と強調状態なら変換も再描画もしない
            if (!heightChanged && start === this.candidateView.start && nextActive === active) { return; }
            // スクロールで見えなくなった候補をEnterで確定しない
            this.activeCandidateIndex = nextActive;
            // 実測高による表示行と余白を同時に反映
            this.refreshCandidateWindow();

        } catch (error) {
            // 処理名を付けてこの画面内へエラーを表示
            this.reportClientError(error, 'handleCandidateScroll', 'ui-event');
        }
    }
    async handleClearObject(event) {
        // 画面イベントの例外をコンポーネント外へ伝播させない
        try {
            // モード切替による初期化と、ルックアップ自身からの解除を区別する。
            const lookup = event?.currentTarget;
            // 取得や保存の途中では適用対象を変更しない
            if (this.busy) { return false; }
            // 確認中に別の対象へ切り替わった場合は解除しない
            const root = this.root;
            // 未保存の分類があれば明示的な破棄を確認
            if (!(await this.confirmDiscard()) || this.busy || this.root !== root) { return false; }
            // 遅延した詳細・分類の応答を未選択状態へ反映しない
            this.detailSequence += 1;
            // 分類取得の対象世代も切り替える
            this.classifySequence += 1;
            // 検索候補の応答と開閉状態を破棄
            this.closeCandidates();
            // 対象必須のため全オブジェクト表示には切り替えない
            this.root = undefined;
            // 前の対象の項目一覧を残さない
            this.detail = undefined;
            // 解除前の図を描画しない
            this.board = { incoming: [], outgoing: [] };
            this.incomingTerm = '';
            this.outgoingTerm = '';
            // 選択状態を未選択へ揃える
            this.selectedKey = 'root';
            // 検索入力を空へ戻す
            this.objectTerm = '';
            // 前の候補を新しい入力へ持ち越さない
            this.options = [];
            // 前の対象の分類データを破棄
            this.classifyData = {};
            // 再選択・取得が終わるまで分類編集を拒否
            this.classifyDataReady = false;
            // 前の処理案内を残さない
            this.setClassifyNotice('');
            // 前の対象のCSVエラーを持ち越さない
            this.csvErrors = [];
            // 検索・ページ条件も対象と同時に解除
            this.fieldSearch = '';

            // 型の条件を解除
            this.fieldType = '';
            // 表示ページを先頭へ戻す
            this.fieldPage = 1;
            // 前の対象のエラーを残さない
            this.error = '';
            // 関連・項目・変更件数を空の対象に同期
            this.rebuild();
            // 解除前の読み取り専用欄が検索欄に置き換わってからフォーカスを戻す。
            if (lookup) {
                await Promise.resolve();
                lookup.focusSearchInput();
            }
            // 呼び出し元は対象の解除が確定した場合だけ種別を変更
            return true;

        } catch (error) {
            // 処理名を付けてこの画面内へエラーを表示
            this.reportClientError(error, 'handleClearObject', 'ui-event');
            return false;
        }
    }
    // 遅延応答を無効にして候補を閉じる
    closeCandidates() {
        // 画面イベントの例外をコンポーネント外へ伝播させない
        try {
            // 次のフォーカス時に新しい候補を表示
            this.candidatesOpen = false;
            // 閉じた候補を強調対象として残さない
            this.activeCandidateIndex = -1;
            // 閉じた候補に強調状態を残さない
            this.refreshCandidateWindow();
            // 古い応答で候補を再表示しない
            this.searchSequence += 1;
            // 取り消した読み込み表示を残さない
            this.candidatesBusy = false;

        } catch (error) {
            // 処理名を付けてこの画面内へエラーを表示
            this.reportClientError(error, 'closeCandidates', 'ui-event');
        }
    }
    // 標準・カスタムを区別せず検索語から候補を取得
    async searchCandidates(allowEmpty = false) {
        // 前回の候補検索の失敗だけを解除
        this.candidateError = undefined;
        // 新しい検索要求では以前のエラー位置を消す
        this.clientError = undefined;
        // 対象未指定の空欄や空白だけの入力で候補を自動表示しない
        if (!allowEmpty && !this.objectTerm.trim()) { this.closeCandidates(); this.options = []; this.candidatesBusy = false; return; }
        // 新しい条件の結果が来るまで古い候補を選べないようにする
        this.options = [];
        // 以前の検索の位置を新しい候補へ対応づけない
        this.activeCandidateIndex = -1;
        // 新しい検索は先頭から描画
        this.candidateScrollTop = 0;
        // 入力欄の下へ結果を表示
        this.candidatesOpen = true;
        // 要求ごとに応答の世代を固定
        const sequence = ++this.searchSequence;
        // 空候補の案内を取得完了まで待つ
        this.candidatesBusy = true;
        // 候補取得の失敗を画面へ通知
        try {
            // ラベル・API名と検索範囲で候補を取得
            const rows = await searchObjects({ term: this.objectTerm });
            // 別の検索や起点変更後に届いた結果を破棄
            if (sequence !== this.searchSequence) { return; }
            // キーボードでも選択できる候補ボタンへ変換
            this.options = rows.map((row) => ({ label: row.label, value: row.apiName }));
        } catch (error) {
            // 古い失敗で現在の検索状態を上書きしない
            if (sequence !== this.searchSequence) { return; }
            // 検索先の失敗を空候補として扱わない
            this.reportClientError(error, 'searchCandidates', 'searchObjects');
            // 空の検索結果と取得失敗を区別
            this.candidateError = 'オブジェクト候補を取得できませんでした。';
            // 取得失敗を候補0件として表示せず、クリックで再試行可能にする
            this.closeCandidates();
        } finally {
            // 最新検索の取得中表示だけを解除
            if (sequence === this.searchSequence) { this.candidatesBusy = false; }
        }
    }
    // 候補をクリックまたはEnterで確定
    async handleCandidate(event) {
        // 画面イベントの例外をコンポーネント外へ伝播させない
        try {
            // 候補ボタンから起点を切り替える
            const name = event.detail.apiName;
            // 現在の可視候補以外は選択として受け付けない
            if (!this.busy && this.options.some((option) => option.value === name)) { await this.loadRoot(name); }

        } catch (error) {
            // 処理名を付けてこの画面内へエラーを表示
            this.reportClientError(error, 'handleCandidate', 'ui-event');
        }
    }
    // 選択済み対象の表示をSLDS入力内へまとめる
    get selectedObjectLabel() { return this.root?.label || ''; }
    // 入力にフォーカスを保ったまま現在の候補を読み上げる
    get activeObjectOptionId() { return this.candidatesOpen && this.options[this.activeCandidateIndex] ? `object-option-${this.options[this.activeCandidateIndex].value}` : null; }
    // 検索・起点選択のすべての経路で候補のモデルを同期
    set options(value) {
        // 取得済みの候補を一つの参照で保持
        this.objectOptions = value;
        // 候補が変わったときだけ表示モデルを更新
        this.refreshCandidateWindow();
    }
    // 現在の候補を検索とキーボード操作で共有
    get options() { return this.objectOptions; }
    // 候補と位置を一つの表示モデルへ確定
    refreshCandidateWindow() {
        // ゲッターごとの同じ行変換を避ける
        this.candidateView = objectOptionWindow(this.options, this.activeCandidateIndex, this.candidateScrollTop, this.candidateRowHeight);
    }
    // 組織エクスプローラーと同じくクリック時の標準スクロールを防ぐ
    handleCardPointerDown(event) {
        // 画面イベントの例外をコンポーネント外へ伝播させない
        try {
            if (event.button !== 0 || event.isPrimary === false) { return; }
            event.preventDefault();
            event.currentTarget.focus({ preventScroll: true });

        } catch (error) {
            // 処理名を付けてこの画面内へエラーを表示
            this.reportClientError(error, 'handleCardPointerDown', 'ui-event');
        }
    }
    // カード選択で詳細だけを切り替える
    async handleCard(event) {
        // 画面イベントの例外をコンポーネント外へ伝播させない
        try {
            // 非同期の確認後にcurrentTargetが失われないよう識別子を先に固定
            const name = event.currentTarget.dataset.name;
            // 同じ相手でも方向を区別
            const key = event.currentTarget.dataset.key || 'root';
            // 起点の読み込み中は以前の図から詳細を変更させない
            if (this.busy || this.saving) { return; }
            // 確認待ちと通信待ちの両方で同じ起点か照合する
            const root = this.root;
            // 関連からの対象変更でも未保存値を確認
            if (!(await this.confirmDiscard())) { return; }
            // 確認中に始まった起点変更を追い越さない
            if (this.busy || this.root !== root) { return; }
            // 遅延応答の採用可否を固定
            const sequence = ++this.detailSequence;
            // 表示中の詳細を優先し、起点へ戻る場合も取得済みの情報を使用
            const current = name === this.detail?.apiName ? this.detail : name === root.apiName ? root : undefined;
            // 日時取得に失敗した情報は再クリックで取得し直せるようにする
            const reusable = current && !current.auditNotice;
            // 新しい操作では前の取得エラーを解除
            this.error = '';
            // 再取得が必要な場合だけ待機表示と操作ロックを開始
            this.busy = !reusable;
            // 別オブジェクトの詳細を読み取る
            try {
                // 図の起点は変えず、選択先の項目と日時だけを取得
                const data = reusable ? current : await this.readObjectInfo(name, 'fields');
                // 起点変更や別の選択後に旧応答を使わない
                if (sequence !== this.detailSequence || this.root !== root) { return; }
                // 起点の日時再取得が成功した場合も関連図の情報を維持
                if (name === root.apiName && data !== root) { this.root = { ...root, fields: data.fields, auditNotice: data.auditNotice }; }
                // 下部の詳細だけを切り替える
                this.detail = name === root.apiName ? this.root : data;
                // 詳細に表示する参照方向を確定
                this.selectedKey = key;
                // オブジェクト変更時は検索条件を解除
                this.fieldSearch = '';

                // データ型を初期状態へ戻す
                this.fieldType = '';
                // 先頭ページから表示
                this.fieldPage = 1;
                // 読み込み完了後に一覧へ案内
                this.revealFields = true;
                // 図上の選択枠を更新
                this.rebuild();
            } catch (error) {
                // 起点変更・別カード選択より前の失敗は表示しない
                if (sequence !== this.detailSequence || this.root !== root) { return; }
                // 有効な要求の失敗だけを診断表示
                this.reportClientError(error, 'handleCard', 'object-info');
                // 表示できない理由を通知
                this.error = getApexMessage(error, '詳細を取得できませんでした。');
            } finally {
                // 現在の要求の終了時だけ読み込み表示を解除
                if (sequence === this.detailSequence) { this.busy = false; }
            }

        } catch (error) {
            // 処理名を付けてこの画面内へエラーを表示
            this.reportClientError(error, 'handleCard', 'ui-event');
        }
    }
    // 選択先を明示的に新しい起点へ変更
    async handleCenter() {
        // 画面イベントの例外をコンポーネント外へ伝播させない
        try {
            // 起点変更の確認中も操作対象を固定
            const name = this.detail.apiName;
            // 中心変更では項目一覧へ自動移動しない
            await this.loadRoot(name, false);
            // 成功した起点変更だけ画面上部へ戻す
            if (this.root?.apiName === name && !this.error) {
                // 新しい起点と参照元・参照先を上部から確認できるようにする
                this.template.querySelector('main')?.scrollIntoView({ block: 'start', behavior: 'auto' });
            }

        } catch (error) {
            // 処理名を付けてこの画面内へエラーを表示
            this.reportClientError(error, 'handleCenter', 'ui-event');
        }
    }
    // 参照元の種類だけを切り替え、参照先の検索条件は維持
    handleIncomingKind(event) {
        // 画面イベントの例外をコンポーネント外へ伝播させない
        try {
            if (this.busy || event.detail.value === this.incomingKind) { return; }
            this.detailSequence += 1;
            this.incomingKind = event.detail.value;
            this.selectedKey = 'root';
            this.detail = this.root;
            this.incomingTerm = '';
            this.fieldSearch = '';

            this.fieldType = '';
            this.fieldPage = 1;

            this.rebuild();

        } catch (error) {
            // 処理名を付けてこの画面内へエラーを表示
            this.reportClientError(error, 'handleIncomingKind', 'ui-event');
        }
    }
    // 検索条件を項目一覧へ反映
    handleFilter(event) {
        // 画面イベントの例外をコンポーネント外へ伝播させない
        try {
            // 保存確認中も検索条件を固定
            if (this.busy) { return; }
            // ラベル・API名の検索とデータ型を区別
            if (event.target.name === 'fieldSearch') { this.fieldSearch = event.target.value; }
            // データ型は選択した型だけへ絞り込む
            else { this.fieldType = event.detail.value; }
            // 絞り込み後は先頭ページへ移動
            this.fieldPage = 1;
            // 利用者が条件を変えたときだけ全件を絞り込む
            this.refreshFields();

        } catch (error) {
            // 処理名を付けてこの画面内へエラーを表示
            this.reportClientError(error, 'handleFilter', 'ui-event');
        }
    }
    // 項目の前後ページを表示
    handlePage(event) {
        // 画面イベントの例外をコンポーネント外へ伝播させない
        try {
            // 保存確認中に編集行の表示ページを切り替えない
            if (this.busy) { return; }
            // 押された方向へ移動
            this.fieldPage += Number(event.currentTarget.dataset.step);
            // ページ内の分類行だけを生成し、以前のページのキャッシュを解放
            this.refreshClassifyRows();

        } catch (error) {
            // 処理名を付けてこの画面内へエラーを表示
            this.reportClientError(error, 'handlePage', 'ui-event');
        }
    }
    // 取得済み定義から表示用一覧を生成
    refreshFields() {
        // 現在の選択オブジェクトの項目だけを処理
        const fields = this.detail?.fields || [];
        // 分類値だけの変更では検索・整列・型候補を再計算しない
        this.fieldView = fieldListView(fields, this.fieldSearch, this.fieldType, this.fieldView, this.isClassify ? this.classifyData : undefined);
        // 検索条件だけで項目一覧を絞り込み、変更有無では除外しない
        this.filtered = this.fieldView.rows;
        // 構造表示の行は再描画やページ移動のたびに整形・整列しない
        this.structureView = this.isReference ? structureFieldView(this.filtered, locale, timeZone, this.structureView) : undefined;
        // 保存後や変更行の解除で存在しないページを表示しない
        this.fieldPage = Math.min(this.fieldPage, Math.max(1, Math.ceil(this.filtered.length / FIELD_PAGE_SIZE)));
        // 検索条件だけの変更では型候補を再生成しない
        this.typeOptions = this.fieldView.typeOptions;
        // 検索・項目定義・保存結果の変更を表示中の分類行へ同期
        this.refreshClassifyRows();
    }
    // 編集・検索・候補開閉のすべてで同じ行単位の再生成経路を使用
    set classifyEdits(value) {
        // 表示用の状態は集計要否によらず更新
        this.classifyState = value;
        // 入力した行だけのモデル更新を候補の開閉にも適用
        this.refreshClassifyRows();
    }
    // 保存用の状態と表示用キャッシュを分離
    get classifyEdits() { return this.classifyState; }
    // 値の変更・取得・保存結果の反映からだけ件数を同期
    refreshClassifySummary() {
        // 候補操作や検索条件の変更では呼び出さない
        const summary = classifySummary(this.classifyEdits);
        // 保存と未保存確認に必要な変更件数を確定
        this.changeCount = summary.changeCount;
        // 未確定入力が残る間は保存を許可しない
        this.inputErrorCount = summary.inputErrorCount;
    }
    // 分類は表示ページの必要な行だけ再生成
    refreshClassifyRows() {
        // 構造モードでは分類の表示モデルを保持しない
        this.classifyView = this.isReference ? undefined : classifyFieldView({
            fields: this.filtered.slice((this.fieldPage - 1) * FIELD_PAGE_SIZE, this.fieldPage * FIELD_PAGE_SIZE),
            classifyData: this.classifyData, edits: this.classifyEdits,
            options: this.classifyOptions, canEdit: this.canEditClassifyData
        }, this.classifyView);
    }
    // 条件に一致する項目がない場合の案内を表示
    get noFields() { return !this.filtered.length; }
    // ページに必要な行だけを描画
    get fieldRows() {
        // 分類の入力・開閉では変更された行だけを事前に再生成済み
        if (!this.isReference) { return this.classifyView?.rows || []; }
        // 構造のページ移動では整形済みの必要な行を切り出すだけにする
        return (this.structureView?.rows || []).slice((this.fieldPage - 1) * FIELD_PAGE_SIZE, this.fieldPage * FIELD_PAGE_SIZE);
    }
    // 選んだカードと起点を結ぶ関係の全項目を詳細へ表示
    get selectedRelation() {
        // 図と同じ監査項目の表示条件で選択を解決
        const relation = this.relations.find((row) => row.key === this.selectedKey);
        // 起点カードには関連項目の一覧を付けない
        return relation ? { title: relation.direction === 'IN' ? `${relation.label} → ${this.root.label}` : `${this.root.label} → ${relation.label}`, links: relation.links.map((link) => ({ ...link, text: `${link.label} (${link.field})：${link.kind}` })) } : undefined;
    }
    // 左右のカードは領域が狭い場合だけ一列にする
    get cardGridClass() { return `c-card-grid${this.narrowRelations ? ' c-card-grid-narrow' : ''}`; }
    // 各列で一致件数と全件数を案内
    get incomingCount() { return `${this.board.incoming.length} / ${this.board.incomingTotal || 0}件`; }
    get outgoingCount() { return `${this.board.outgoing.length} / ${this.board.outgoingTotal || 0}件`; }
    get noIncoming() { return !this.board.incoming.length; }
    get noOutgoing() { return !this.board.outgoing.length; }
    // 一覧のページ状態を表示
    get pageLabel() { return `${this.fieldPage} / ${Math.max(1, Math.ceil(this.filtered.length / FIELD_PAGE_SIZE))}ページ・${this.filtered.length}項目`; }
    // 起点の重複変更を抑止
    get centerDisabled() { return this.busy || this.root?.apiName === this.detail?.apiName; }
    // 最初のページより前へ進ませない
    get previousDisabled() { return this.busy || this.fieldPage <= 1; }
    // 最後のページより後へ進ませない
    get nextDisabled() { return this.busy || this.fieldPage * FIELD_PAGE_SIZE >= this.filtered.length; }
    // モード変更・対象変更前に変更の破棄を確認
    async confirmDiscard() {
        // 保存処理中は変更件数が減っても移動させない
        if (this.saving) { return false; }
        // 変更がなければ確認せず遷移
        if (!this.changeCount && !this.inputErrorCount) { this.classifyEdits = {}; return true; }
        // 破棄確認の表示失敗でも遷移や未保存入力の破棄を行わない
        const version = this.connectionVersion;
        // 確認結果が戻った時に同じ画面か照合する。
        try {
            // 破棄を明示的に選んだ場合だけ移動
            const confirmed = await LightningConfirm.open({ message: '未保存のデータ分類があります。変更を破棄して移動しますか？', label: '未保存の変更', theme: 'warning' });
            // キャンセル時は入力を維持
            if (version !== this.connectionVersion) return false;
            // 現在の画面の同意だけを編集状態へ反映する。
            if (confirmed) { this.classifyEdits = {}; this.refreshClassifySummary(); }
            // 呼び出し元で遷移を判断
            return confirmed;
        } catch (error) {
            // 確認画面の失敗箇所を表示し、既存の画面を維持
            if (version !== this.connectionVersion) return false;
            // 現在の確認で発生した失敗を表示する。
            this.reportClientError(error, 'confirmDiscard', 'confirmation');
            // 表示失敗を破棄への同意として扱わない
            return false;
        }
    }
    // 未保存変更の確認後、対象を解除して新しいモードを初期表示
    async handleMode(event) {
        // 画面イベントの例外をコンポーネント外へ伝播させない
        try {
            // 確認中は現在のモードを操作元にも維持
            const control = event.target;
            // 選択された次のモードだけを確定後に反映
            const next = event.detail.value;
            // キャンセルした場合に選択表示だけ先行させない
            control.value = this.mode;
            // 同じモードの再選択や処理中は状態を変えない
            if (next === this.mode || this.busy) { return; }
            // 対象の解除と同じ確認・検索状態の破棄を使用
            if (!(await this.handleClearObject())) { return; }
            // 参照元の絞り込みも初期値へ戻す
            this.incomingKind = 'standard';
            // 前の対象の分類候補を持ち越さない
            this.classifyOptions = { ComplianceGroup: [], SecurityClassification: [], BusinessStatus: [] };
            // 前の保存結果を初期状態へ戻す
            this.saveSuccessCount = 0;
            // 前の失敗件数を持ち越さない
            this.saveFailureCount = 0;
            // 未選択状態で項目一覧へスクロールさせない
            this.revealFields = false;
            // 対象は未選択のまま新しいモードへ切り替え
            this.mode = next;

        } catch (error) {
            // 処理名を付けてこの画面内へエラーを表示
            this.reportClientError(error, 'handleMode', 'ui-event');
        }
    }
    // 分類読取を参照モードのDescribe処理から分離
    async loadClassifyData(preserveEdits = false) {
        // 未選択や読み取りモードでは通信しない
        if (this.isReference || !this.detail) { return; }
        // 新しい要求の世代を固定
        const sequence = ++this.classifySequence;
        // 分類読取の失敗を画面へ通知
        try {
            // 組織の分類値と選択肢を一括で取得
            const result = await getClassifyData({ objectName: this.detail.apiName });
            // 別の対象へ切り替わった応答を採用しない
            if (sequence !== this.classifySequence) { return; }
            // 認証確認の待機中に始めた編集も破棄しない
            if (preserveEdits && (this.changeCount || this.hasInputErrors)) return;
            // 項目API名の索引を保持
            this.classifyData = result.rows;
            // API名と表示ラベルを分けた選択肢を保持
            this.classifyOptions = result.options;
            this.classifyEdits = this.canEditClassifyData ? createClassifyEdits(result.rows) : {};
            // 値または入力エラーの変更を保存可否へ反映
            this.refreshClassifySummary();
            // 読み取り完了後だけ編集開始を許可
            this.classifyDataReady = true;
            // 取得済みの編集可否を件数・型候補・ページへ反映
            this.refreshFields();
            // 保存前の案内を表示
            this.setClassifyNotice(this.canEditClassifyData ? '分類を変更すると行がハイライトされます。「保存」で変更した項目をまとめて保存します。' : 'データ分類は参照のみです。変更には「データ分類の変更」または「オブジェクトのカスタマイズ」権限が必要です。');
        } catch (error) {
            // 分類取得と画面モデルの生成失敗を識別
            this.reportClientError(error, 'loadClassifyData', 'classify-data');
            // 取得できなかった情報を未設定値として扱わない
            this.setClassifyNotice(getApexMessage(error, 'データ分類を取得できませんでした。'), true);
        }
    }
    // 選択候補を行の高さに影響しない領域へ表示
    handleComplianceToggle(event) {
        // 画面イベントの例外をコンポーネント外へ伝播させない
        try {
            // 項目API名で選択状態と表示状態を同じ行へ結び付ける
            const apiName = event.currentTarget.dataset.field;
            // 保存中や参照専用の入力は開かない
            const state = this.classifyEdits[apiName];
            // 取得済みで権限のある行だけ操作
            if (!this.canEditClassifyData || this.busy || !state) { return; }
            // 一覧の下端で候補が切れないよう開く方向を決める
            const rect = event.currentTarget.getBoundingClientRect();
            // 固定ヘッダーを含むスクロール領域を基準にする
            const area = event.currentTarget.closest('.c-table-scroll').getBoundingClientRect();
            // 固定ヘッダーへ重ならない範囲だけを上側の余白として扱う
            const headerHeight = event.currentTarget.closest('table').querySelector('thead').getBoundingClientRect().height;
            // 既存の非アクティブ値も含めた候補数から必要な高さを見積もる
            const optionCount = new Set([...this.classifyOptions.ComplianceGroup.map((option) => option.value), ...(state.original.complianceGroup || '').split(';').filter(Boolean)]).size;
            // 下端の行では十分な余白のある上側だけに開く
            const popupHeight = Math.min(240, optionCount * 24 + 48);
            // 狭い一覧の先頭行で固定ヘッダーの裏へ候補を出さない
            const above = area.bottom - rect.bottom < popupHeight && rect.top - area.top - headerHeight >= popupHeight;
            // 分類値は変更せず候補の開閉だけ反映
            this.classifyEdits = { ...this.classifyEdits, [apiName]: { ...state, complianceOpen: !state.complianceOpen, complianceAbove: above } };

        } catch (error) {
            // 処理名を付けてこの画面内へエラーを表示
            this.reportClientError(error, 'handleComplianceToggle', 'ui-event');
        }
    }
    // マウスで候補を押す間はフォーカス離脱で選択を中断させない
    handleCompliancePointerDown(event) {
        // 画面イベントの例外をコンポーネント外へ伝播させない
        try {     event.preventDefault();
        } catch (error) {
            // 処理名を付けてこの画面内へエラーを表示
            this.reportClientError(error, 'handleCompliancePointerDown', 'ui-event');
        }
    }
    // 別の入力へ移動したら候補だけを閉じる
    handleComplianceBlur(event) {
        // 画面イベントの例外をコンポーネント外へ伝播させない
        try {
            // チェックボックス間の移動では開いたままにする
            if (event.currentTarget.contains(event.relatedTarget)) { return; }
            // 表示中の行だけ更新
            const apiName = event.currentTarget.dataset.field;
            // ページ切り替え後の遅延イベントを無視
            const state = this.classifyEdits[apiName];
            // 選んだ分類は閉じても保持
            if (state) { this.classifyEdits = { ...this.classifyEdits, [apiName]: { ...state, complianceOpen: false } }; }

        } catch (error) {
            // 処理名を付けてこの画面内へエラーを表示
            this.reportClientError(error, 'handleComplianceBlur', 'ui-event');
        }
    }
    // Escapeで候補を閉じて元の選択欄へ戻す
    handleComplianceKeydown(event) {
        // 画面イベントの例外をコンポーネント外へ伝播させない
        try {
            // 標準チェックボックスのキー操作を維持
            if (event.key !== 'Escape') { return; }
            // 他の領域のEscape処理と競合させない
            event.preventDefault();
            // 開閉処理と同じ行を使用
            const apiName = event.currentTarget.dataset.field;
            // 現在の入力値を保持
            const state = this.classifyEdits[apiName];
            // 編集状態が残る場合だけ閉じる
            if (state) { this.classifyEdits = { ...this.classifyEdits, [apiName]: { ...state, complianceOpen: false } }; }
            // 閉じた候補にフォーカスを残さない
            event.currentTarget.querySelector('button').focus();

        } catch (error) {
            // 処理名を付けてこの画面内へエラーを表示
            this.reportClientError(error, 'handleComplianceKeydown', 'ui-event');
        }
    }
    // 個々の設定変更を元の値と比較できる状態で保存
    handleClassifyChange(event) {
        // 画面イベントの例外をコンポーネント外へ伝播させない
        try {
            // 項目API名からページ外でも同じ編集行を特定
            const apiName = event.target.dataset.field;
            // 変更する分類属性を限定
            const key = event.target.dataset.property;
            // 未取得の行は編集させない
            const state = this.classifyEdits[apiName];
            // 保存中の値変更を拒否
            if (!this.canEditClassifyData || !state || this.saving) { return; }
            // 候補に対応することを確認した値だけを反映
            const input = classifyInput(key, event.detail.value, this.classifyOptions, state.original);
            // 不明な入力を空値や以前の選択として保存させない
            if (!input.valid) {
                // 修正されるまで該当行と保存を入力エラーとして扱う
                this.classifyEdits = { ...this.classifyEdits, [apiName]: { ...state, inputErrors: { ...state.inputErrors, [key]: input.message } } };
                // 値または入力エラーの変更を保存可否へ反映
                this.refreshClassifySummary();
                // 確認できない値は変更しない
                return;
            }
            // 他の行の入力は保持して、確定した値とエラー解除を反映
            this.classifyEdits = { ...this.classifyEdits, [apiName]: { ...state, draft: { ...state.draft, [key]: input.value }, inputErrors: { ...state.inputErrors, [key]: '' }, error: '' } };
            // 値または入力エラーの変更を保存可否へ反映
            this.refreshClassifySummary();

        } catch (error) {
            // 処理名を付けてこの画面内へエラーを表示
            this.reportClientError(error, 'handleClassifyChange', 'ui-event');
        }
    }
    // 入力または欄を開く操作で所有者候補を検索
    handleOwnerSearch(event) {
        // 画面イベントの例外をコンポーネント外へ伝播させない
        try {
            // 入力した行と確定した検索語を固定
            const apiName = event.target.dataset.field;
            // 後続の応答でも同じ検索語を使用
            const term = event.target.value;
            // 編集中の行だけを検索対象にする
            const state = this.classifyEdits[apiName];
            // 保存中や参照専用の操作では通信しない
            if (!this.canEditClassifyData || this.busy || !state || state.owner.value) { return; }
            // 空欄のクリックや空白だけの入力では検索せず候補を閉じる
            const open = Boolean(term.trim());
            // 同じ候補を開いている間のクリックによる二重検索を防ぐ
            if (open && state.ownerOpen && state.ownerQuery === term) { return; }
            // 行ごとの最新要求だけを採用
            const sequence = ++this.ownerSequence;
            // 所有者IDを維持して古い検索候補だけを外す
            this.classifyEdits = { ...this.classifyEdits, [apiName]: { ...state, ownerSearch: term, ownerQuery: open ? term : undefined, ownerLoading: open, ownerRequest: sequence, ownerOpen: open, ownerActive: -1, ownerOptions: createOwnerOptions([], state.owner) } };
            // フォーカス移動を待たず入力時に通信を開始
            if (open) { this.searchOwnerCandidates(apiName, term, sequence); }

        } catch (error) {
            // 処理名を付けてこの画面内へエラーを表示
            this.reportClientError(error, 'handleOwnerSearch', 'ui-event');
        }
    }
    // 確定した検索語の候補を取得し、同じ行の最新要求だけへ反映
    async searchOwnerCandidates(apiName, term, sequence) {
        // 破棄済み・選択済みの行や画面終了後には通信しない
        if (!this.componentConnected || sequence !== this.classifyEdits[apiName]?.ownerRequest || this.saving) { return; }
        // 最新結果だけを行へ設定
        try {
            // 所有者候補の取得は表示名で検索
            const options = await searchClassifyOwners({ term });
            // 削除済み行や古い応答へ反映しない
            if (!this.componentConnected || this.saving || sequence !== this.classifyEdits[apiName]?.ownerRequest) { return; }
            // 応答待ちに変更された選択も検索結果から消さない
            const state = this.classifyEdits[apiName];
            // 同じIDの最新候補があればIDと表示名の組として差し替える
            const owner = options.find((option) => option.value === state.owner.value) || state.owner;
            // 現在の選択値を検索結果と一緒に保持
            this.classifyEdits = { ...this.classifyEdits, [apiName]: { ...state, owner, ownerLoading: false, ownerSearch: term, ownerOptions: createOwnerOptions(options, owner) } };
            // 検索が完了したことと該当件数を明示
            this.setClassifyNotice(`所有者候補を${options.length}件取得しました。`);
        } catch (error) {
            // 終了済みの編集から失敗通知を戻さない
            if (!this.componentConnected || this.saving || sequence !== this.classifyEdits[apiName]?.ownerRequest) { return; }
            // 保存処理以外の所有者検索エラーも処理名を表示
            this.reportClientError(error, 'searchOwnerCandidates', 'owner-search');
            // 同じ検索語のクリックを重複要求として拒否しない
            const state = this.classifyEdits[apiName];
            // 入力と選択値は維持し、失敗した候補の状態だけを解除
            this.classifyEdits = { ...this.classifyEdits, [apiName]: { ...state, ownerQuery: undefined, ownerLoading: false, ownerOpen: false, ownerActive: -1 } };
            // 検索に失敗した理由を通知
            this.setClassifyNotice(getApexMessage(error, '所有者候補を取得できませんでした。'), true);
        }
    }
    // 候補を押しても検索入力からフォーカスを失わせない
    handleOwnerPointerDown(event) {
        // 画面イベントの例外をコンポーネント外へ伝播させない
        try {     event.preventDefault();
        } catch (error) {
            // 処理名を付けてこの画面内へエラーを表示
            this.reportClientError(error, 'handleOwnerPointerDown', 'ui-event');
        }
    }
    // 別の操作へ移った行の候補だけを閉じる
    handleOwnerBlur(event) {
        // 画面イベントの例外をコンポーネント外へ伝播させない
        try {
            // 同じルックアップ内の操作は継続
            if (event.currentTarget.contains(event.relatedTarget)) { return; }
            // 他の行の入力状態は変えない
            const apiName = event.currentTarget.dataset.field;
            // ページ切り替えで消えた行への通知を無視
            const state = this.classifyEdits[apiName];
            // 未確定の検索結果を再表示しない
            if (state) { this.classifyEdits = { ...this.classifyEdits, [apiName]: { ...state, ownerOpen: false, ownerRequest: ++this.ownerSequence } }; }

        } catch (error) {
            // 処理名を付けてこの画面内へエラーを表示
            this.reportClientError(error, 'handleOwnerBlur', 'ui-event');
        }
    }
    // 選択解除も所有者IDの明示的な変更として保持
    async handleOwnerClear(event) {
        // 画面イベントの例外をコンポーネント外へ伝播させない
        try {
            // 操作した行だけを特定
            const apiName = event.currentTarget.dataset.field;
            // 保存中と権限不足の操作は受け付けない
            if (!this.canEditClassifyData || this.busy || !this.classifyEdits[apiName]) { return; }
            // 再描画で解除ボタンが消える前に、同じ行の所有者欄を保持する。
            const lookup = event.currentTarget.closest('.c-owner-lookup');
            // IDと表示名を一緒に解除して古い検索応答を無効化
            this.classifyEdits = { ...this.classifyEdits, [apiName]: { ...this.classifyEdits[apiName], owner: { value: '', label: '' }, ownerSearch: '', ownerOpen: false, ownerActive: -1, ownerRequest: ++this.ownerSequence, inputErrors: { ...this.classifyEdits[apiName].inputErrors, owner: '' }, error: '' } };
            // 値または入力エラーの変更を保存可否へ反映
            this.refreshClassifySummary();
            // 読み取り専用欄が空の検索欄に切り替わった後、次の入力を受け付ける。
            await Promise.resolve();
            lookup.querySelector('input:not([readonly])')?.focus();

        } catch (error) {
            // 処理名を付けてこの画面内へエラーを表示
            this.reportClientError(error, 'handleOwnerClear', 'ui-event');
        }
    }
    // 検索入力へフォーカスを残したまま候補を選ぶ
    handleOwnerKeydown(event) {
        // 画面イベントの例外をコンポーネント外へ伝播させない
        try {
            // IME変換中のEnterでは検索・選択しない
            if (event.isComposing) { return; }
            // 別の行の候補へ選択を流用しない
            const apiName = event.currentTarget.dataset.field;
            // 保存中はキーボード操作も拒否
            const state = this.classifyEdits[apiName];
            // 保存中と存在しない行は変更しない
            if (!state || this.busy) { return; }
            // 選択済みのpillをDeleteで解除し、既存の保存可否判定を使う
            if (state.owner.value) {
                // 解除ボタンと同じ権限・要求世代の検証を通す
                if (event.key === 'Delete') { event.preventDefault(); this.handleOwnerClear(event); }
                // 選択済み名称は候補検索へ流用しない
                return;
            }
            // 空値を含まない表示候補と同じ順番を使用
            const options = state.ownerOptions.filter((option) => option.value);
            // Escapeは値を変えず候補だけ閉じる
            if (event.key === 'Escape') { event.preventDefault(); this.classifyEdits = { ...this.classifyEdits, [apiName]: { ...state, ownerOpen: false, ownerRequest: ++this.ownerSequence } }; return; }
            // 対象オブジェクトと同じく、検索語がある場合だけ上下キーで候補を開く
            if (!state.ownerOpen && ['ArrowDown', 'ArrowUp'].includes(event.key)) { event.preventDefault(); this.handleOwnerSearch(event); return; }
            // 閉じた候補をEnterで確定しない
            if (!state.ownerOpen) { return; }
            // Enterは強調した候補、または唯一の候補を選択
            if (event.key === 'Enter') {
                // 表示中の同じ候補配列から選択対象を固定
                const option = options[state.ownerActive] || (options.length === 1 ? options[0] : undefined);
                // 候補が一意に決まらなければ変更しない
                if (option) { event.preventDefault(); this.handleOwnerSelect({ currentTarget: { dataset: { field: apiName, value: option.value } } }); }
                // Enterを他の入力操作へ伝播させない
                return;
            }
            // 上下キーは候補の範囲内を循環
            if (['ArrowDown', 'ArrowUp'].includes(event.key) && options.length) {
                // ページ全体がスクロールしないようにする
                event.preventDefault();
                // 未選択から上キーなら末尾へ移動
                const active = state.ownerActive ?? -1;
                // 表示行にだけ選択位置を保持
                this.classifyEdits = { ...this.classifyEdits, [apiName]: { ...state, ownerOpen: true, ownerActive: event.key === 'ArrowDown' ? (active + 1) % options.length : (active <= 0 ? options.length : active) - 1 } };
            }

        } catch (error) {
            // 処理名を付けてこの画面内へエラーを表示
            this.reportClientError(error, 'handleOwnerKeydown', 'ui-event');
        }
    }
    // 所有者の種類と識別名を二つの属性へ排他的に反映
    handleOwnerSelect(event) {
        // 画面イベントの例外をコンポーネント外へ伝播させない
        try {
            // 入力対象の行を固定
            const apiName = event.currentTarget.dataset.field;
            // 保存中は値を固定
            if (!this.canEditClassifyData || this.saving) { return; }
            // 保存用のIDは選択肢に存在する候補からだけ採用
            const state = this.classifyEdits[apiName];
            // 取り消した行へ遅延したイベントを反映しない
            if (!state) { return; }
            // IDと表示名が結び付いた候補をそのまま選択
            const owner = state.ownerOptions.find((option) => option.value === event.currentTarget.dataset.value);
            // 対応がない値を未設定や別の候補へ置き換えない
            if (!owner) { this.classifyEdits = { ...this.classifyEdits, [apiName]: { ...state, inputErrors: { ...state.inputErrors, owner: '有効な所有者候補から選択してください。入力が確定するまで保存できません。' } } }; this.refreshClassifySummary(); return; }
            // Metadata APIの識別名はクライアントでは生成しない
            this.classifyEdits = { ...this.classifyEdits, [apiName]: { ...state, owner, ownerOpen: false, ownerActive: -1, ownerSearch: '', ownerRequest: ++this.ownerSequence, inputErrors: { ...state.inputErrors, owner: '' }, error: '' } };
            // 値または入力エラーの変更を保存可否へ反映
            this.refreshClassifySummary();

        } catch (error) {
            // 処理名を付けてこの画面内へエラーを表示
            this.reportClientError(error, 'handleOwnerSelect', 'ui-event');
        }
    }
    // 確認から保存まで同時に一つの出力だけを所有する。
    exportController;
    // ブラウザの保存開始後も次の出力または離脱までURLを維持する。
    downloadUrl;

    // 保持中のCSVをブラウザから解放する。
    releaseDownload() {
        // 初回は解放対象がない。
        if (!this.downloadUrl) return;
        // 直前のファイルだけを解放する。
        URL.revokeObjectURL(this.downloadUrl);
        // 同じURLを二重に解放しない。
        this.downloadUrl = undefined;
    }

    // モードごとの対象件数を確認し、共通モーダルで進捗を表示する。
    async handleExportCsv() {
        // 確認中の連打と不完全な入力からの出力を防ぐ。
        if (this.exportController || this.csvExportDisabled) return;
        // 画面を離れると同じインスタンスへ戻っても無効になる。
        const controller = new AbortController();
        // 次の確認を開始するまでこの操作だけを追跡する。
        this.exportController = controller;
        try {
            // 確認した対象・モード・編集値を一つの出力に固定する。
            const detail = this.detail;
            // 項目定義と分類は列数と対象項目が異なる。
            const reference = this.isReference;
            // 分類モードでは確認時点の入力を使用する。
            const edits = this.classifyEdits;
            // 対象の判定と件数表示に同じ一覧を使う。
            const savedClassification = this.classifyData;
            // 確認に表示した対象を出力時にも使用する。
            const fields = csvFields(detail.fields, reference, savedClassification);
            // 離脱や対象変更後に古いファイルを保存しない。
            const current = () => !controller.signal.aborted && this.detail === detail && this.isReference === reference && !this.csvExportDisabled;
            // 全件の作成とモーダルの正常終了が揃った場合だけ保存する。
            let file;
            // 設定変更履歴と同じ確認・進捗・キャンセル・再試行を使う。
            const completed = await CsvExportModal.open({
                size: 'small', label: 'CSV出力', ownerSignal: controller.signal,
                exportSubject: `${detail.label}（${detail.apiName}）の${reference ? '項目定義' : 'データ分類'} 全${fields.length.toLocaleString('ja-JP')}件`,
                buildFile: async (_selection, isOpen, progress) => {
                    // 閉じたモーダルから読み取りを開始しない。
                    if (!current() || !isOpen()) return;
                    // 構造CSVの保存済み分類だけを出力時に取得する。
                    let classification = savedClassification;
                    try {
                        // 編集権限がなくても閲覧可能な保存済み分類を利用する。
                        if (reference) classification = (await getClassifyData({ objectName: detail.apiName })).rows;
                    } catch (error) {
                        // 失敗した処理位置を記録し、モーダルには再試行の案内を返す。
                        if (current() && isOpen()) this.reportClientError(error, 'handleExportCsv', 'ui-event');
                        // 応答本文や内部情報は利用者向けの案内へ転記しない。
                        throw new Error('データ分類を取得できませんでした。もう一度出力してください。');
                    }
                    // 進捗とファイル本体に同じ順序・同じ明細を使う。
                    const groups = csvParts({ fields, reference, locale, timeZone, classification, edits, objectName: detail.apiName, objectLabel: detail.label });
                    // 全件が揃った場合だけモーダル終了後の保存対象にする。
                    file = await buildCsvBlob(groups, () => current() && isOpen(), progress);
                }
            });
            // 閉じるアニメーション中に対象を離れた場合も保存しない。
            if (!completed || !file || !current()) return;
            // 直前のダウンロード用URLと入れ替える。
            this.releaseDownload();
            // テンプレート内のリンクからローカルへ保存する。
            this.downloadUrl = URL.createObjectURL(file);
            // このコンポーネントに属するリンクだけを使用する。
            const link = this.template.querySelector('[data-download]');
            // ファイル名には対象API名と利用者のタイムゾーンを使用する。
            link.download = csvFileName(detail.apiName, reference, new Date(), timeZone);
            // 作成したファイルだけを保存先へ渡す。
            link.href = this.downloadUrl;
            // 完成したCSVのダウンロードを開始する。
            link.click();
        } catch (error) {
            // モーダル自体やダウンロードの失敗を親画面で通知する。
            if (!controller.signal.aborted) this.reportClientError(error, 'handleExportCsv', 'ui-event');
        } finally {
            // 古い処理で新しい出力のロックを解除しない。
            if (this.exportController === controller) this.exportController = undefined;
        }
    }
    // CSVを全件確認した後で入力欄へ反映し、保存は既存ボタンへ委ねる
    async handleImportCsv(event) {
        // 画面イベントの例外をコンポーネント外へ伝播させない
        try {
            // ファイル選択キャンセルでは現在の入力を変更しない
            const file = event.target.files?.[0];
            // 未取得・参照専用・通信中の取り込みを拒否
            if (!file || this.csvDisabled) { return; }
            // 同じファイルも修正後に選び直せる状態へ戻す
            event.target.value = '';
            // 読取中に対象が変わった場合の結果反映を抑止
            const detail = this.detail;
            // 分類の取得世代と同じ境界でCSVを照合
            const sequence = this.classifySequence;
            // ファイル読取と候補確認の間は編集・対象変更を抑止
            const version = this.connectionVersion;
            // 接続・対象・分類が一致する操作だけが結果を所有する。
            const current = () => version === this.connectionVersion && this.componentConnected && this.detail === detail && this.classifySequence === sequence;
            // 画面離脱時に読取や確認を中断できるようにする。
            this.pendingInput = 'import';
            // 取込中の入力変更を止める。
            this.busy = true;
            // 前回のCSVエラーだけを解除
            this.csvErrors = [];
            // ファイルを読む段階も処理中と通知
            this.setClassifyNotice('CSVを確認しています…');
            try {
                // 過大なファイルをブラウザの状態へ展開しない
                if (!/\.csv$/iu.test(file.name) || file.size > CLASSIFY_CSV_LIMITS.bytes) { throw new Error(`${CLASSIFY_CSV_LIMITS.bytes / (1024 * 1024)}MiB以下のUTF-8 CSVファイルを選択してください。`); }
                // ファイル読取はLWCのControllerに残す
                const text = await new Promise((resolve, reject) => {
                    // 利用者が選択したローカルファイルだけを読み取る
                    const reader = new FileReader();
                    // ファイル内容はサーバーへアップロードしない
                    reader.onload = () => resolve(reader.result);
                    // 読取失敗を空のCSVとして扱わない
                    reader.onerror = () => reject(new Error('CSVファイルを読み取れませんでした。'));
                    // Excelで保存する際もUTF-8を使用
                    reader.readAsText(file, 'UTF-8');
                });
                // 別の画面・対象の分類へ読取結果を対応付けない
                if (!current()) { return; }
                // CSVの列・項目・候補値を既存の入力規則で確認
                const parsed = readClassifyCsv(text, detail.apiName, this.classifyEdits, this.classifyOptions, this.classifyData, detail.fields);
                // 行エラーがあれば所有者検索も入力反映も行わない
                if (parsed.errors.length) { this.csvErrors = parsed.errors; this.setClassifyNotice('CSVにエラーがあります。入力内容は変更していません。', true); return; }
                // 追加確認が必要な所有者IDだけをまとめて照合
                const batches = classifyOwnerBatches(parsed.ownerIds);
                // 分割照合の途中で入力を反映せず、すべての結果を待つ
                const owners = await batches.reduce((pending, batch) => pending.then(async (known) => {
                    // 別の画面・対象へ移った後は追加要求を送らない
                    if (!current()) { return known; }
                    // 所有者の読取だけを小分けに実行
                    const response = await resolveClassifyOwners({ idsJson: JSON.stringify(batch) });
                    // 各バッチのID対応を検証してから集約
                    return mergeClassifyOwners(batch, response, known);
                }), Promise.resolve({}));
                // 所有者確認中の画面変更を採用しない
                if (!current()) { return; }
                // 対象外の手入力は維持し、CSVの同じ行だけへ合成
                const result = applyClassifyCsv(parsed.rows, owners, this.classifyEdits, ++this.ownerSequence);
                // IDの不足や無効ユーザーも全体を反映しない
                if (result.errors.length) { this.csvErrors = result.errors; this.setClassifyNotice('CSVの所有者を確認してください。入力内容は変更していません。', true); return; }
                // 既存の未保存変更をCSVで置き換える前だけ確認
                if (this.changeCount || this.inputErrorCount) {
                    // 保存は行わず画面の未保存入力だけを置き換える
                    const confirmed = await LightningConfirm.open({ label: 'CSVの反映', message: 'CSVに含まれる項目の未保存変更を置き換えますか？CSVにない項目の変更は保持します。', theme: 'warning' });
                    // キャンセルでは入力と保存基準を維持
                    if (!current()) return;
                    // 現在の画面だけにキャンセルを通知する。
                    if (!confirmed) { this.setClassifyNotice('CSVの反映を中止しました。入力内容は変更していません。'); return; }
                }
                // 確認ダイアログの待機中も同じ対象であることを確認
                if (!current()) { return; }
                // 全件の検証後だけ既存の編集状態へ適用
                this.classifyEdits = result.edits;
                // 値または入力エラーの変更を保存可否へ反映
                this.refreshClassifySummary();
                // この段階では分類を更新していないことを通知
                this.setClassifyNotice(`CSVから${parsed.rows.length}項目を入力欄へ反映しました。変更内容を確認して「保存」を押してください。`);
            } catch (error) {
                // ファイル本文を記録せずCSV処理の失敗箇所を表示
                if (!current()) return;
                // 現在の取込の失敗だけを表示する。
                this.reportClientError(error, 'handleImportCsv', 'csv-import');
                // エラー本文へファイル全体や内部例外を含めない
                this.csvErrors = [{ line: 1, message: reduceErrors(error, 'CSVを確認できませんでした。') }];
                // 読取・照合失敗では元の入力をそのまま保持
                this.setClassifyNotice('CSVを取り込めませんでした。入力内容は変更していません。', true);
            } finally {
                // 元の要求の対象だけ操作を再開
                if (current()) {
                    // この接続の取込処理を終了する。
                    this.pendingInput = undefined;
                    // 他の接続のロックには触れない。
                    this.busy = false;
                }
            }

        } catch (error) {
            // 処理名を付けてこの画面内へエラーを表示
            this.reportClientError(error, 'handleImportCsv', 'ui-event');
        }
    }
    // CSVの上限と空値の意味は操作横のヘルプへ集約
    get csvHelp() { return `UTF-8・${CLASSIFY_CSV_LIMITS.bytes / (1024 * 1024)}MiB・${CLASSIFY_CSV_LIMITS.rows.toLocaleString('ja-JP')}行以内のCSVを使用します。空欄は未設定、複数のコンプライアンス分類は ; 区切りです。所有者は18桁IDを指定します。読み込み後に「保存」で更新します。`; }
    // 分類取得済みの編集利用者だけCSVを操作
    get csvDisabled() { return !this.canEditClassifyData || this.busy || !this.classifyDataReady || !this.detail; }
    // 未確定の入力をCSVの確定値として出力しない
    get csvExportDisabled() { return this.busy || !this.detail || (this.isClassify && (!this.classifyDataReady || this.hasInputErrors)); }
    // エラー一覧は空の場合に描画しない
    get hasCsvErrors() { return this.csvErrors.length > 0; }
    // 変更内容を確認して少数ずつ保存
    async handleSaveClassifyData() {
        // 再接続後の新しい操作とこの保存を区別する
        const operationVersion = this.connectionVersion;
        // 例外が発生した処理段階を保存前と保存中で区別
        let phase = 'preparation';
        // 二重クリックの早期終了で先行処理のロックを解除しない
        let ownsSaveLock = false;
        // 保存要求の組み立てから確認画面の表示まで同じ捕捉範囲にする
        try {
            // 終了した画面から保存を開始しない
            if (!this.componentConnected) { return; }
            // 処理中は通知やロックを先行処理へ任せる
            if (this.busy || this.saving) { return; }
            // 保存対象がない場合や入力エラーを無反応のままにしない
            if (!this.detail || this.saveDisabled) {
                // 保存できない理由を既存の案内領域へ表示
                this.setClassifyNotice(this.hasInputErrors ? '入力エラーを修正してから保存してください。' : '保存できる変更がありません。対象と分類の取得状態・編集権限を確認してください。', true);
                // 確認なしで保存処理を開始しない
                return;
            }
            // 再試行時に以前の診断表示を消す
            this.clientError = undefined;
            // 確認開始時の対象と編集内容を一組で固定
            const detail = this.detail;
            // 対象を再取得した場合も以前の確認を採用しない
            const sequence = this.classifySequence;
            // 変更行の生成で起きるJS例外も保存前の失敗として扱う
            const changes = classifyChanges(this.classifyEdits);
            // 確認中から入力変更・対象変更・二重保存を抑止
            this.saving = true;
            // 既存のスピナーと操作要素の無効化を共用
            this.busy = true;
            // この要求が設定したロックだけを最後に解除
            ownsSaveLock = true;
            // 以前の要求の集計を混ぜない
            this.saveSuccessCount = 0;
            // 部分失敗も要求単位で集計
            this.saveFailureCount = 0;
            // 保存前の失敗と保存開始後の失敗を区別する
            phase = 'confirmation';
            // 確認画面には更新する項目数だけを案内
            const confirmed = await LightningConfirm.open({ label: '保存の確認', message: `${changes.length}項目のデータ分類を保存しますか？`, theme: 'warning' });
            // 確認した対象が有効な間だけ更新を開始
            if (!this.componentConnected || operationVersion !== this.connectionVersion || this.detail !== detail || this.classifySequence !== sequence) { return; }
            // キャンセルと表示失敗を混同しない
            if (!confirmed) { this.setClassifyNotice('保存をキャンセルしました。'); return; }
            // 保存開始後は未実行と案内せず確認済みの件数を表示
            phase = 'saving';
            // 確認済みの保存をスクロール位置に依存せず案内
            this.saveInProgress = true;
            // 固定したオブジェクトと変更内容を少数ずつ順に処理
            await this.saveClassifyRows(detail.apiName, changes, operationVersion);
            // 古い保存の完了案内で復帰後の状態を上書きしない
            if (!this.componentConnected || operationVersion !== this.connectionVersion) { return; }
            // 完了時には成功・失敗を混同せず表示
            this.setClassifyNotice(this.saveFailureCount ? `保存結果：成功${this.saveSuccessCount}件・失敗${this.saveFailureCount}件。失敗した項目の編集内容は保持しています。` : `${this.saveSuccessCount}項目のデータ分類を保存しました。`, this.saveFailureCount > 0);
        } catch (error) {
            // 離脱前の失敗を復帰後の操作へ反映しない
            if (!this.componentConnected || operationVersion !== this.connectionVersion) { return; }
            // 保存の準備・確認表示・API実行を識別して画面内へ表示
            this.reportClientError(error, 'handleSaveClassifyData', phase);
            // 保存後の例外では成功を確認できた件数を維持
            if (phase === 'saving') {
                // 自動再実行せず最新状態の確認を案内
                this.setClassifyNotice(`成功確認済み${this.saveSuccessCount}件。処理を中断しました。${getApexMessage(error, '最新状態を確認してから再操作してください。')}`, true);
            } else {
                // 準備失敗と確認画面の表示失敗を識別し、更新未実行を明示
                this.setClassifyNotice(`${phase === 'confirmation' ? '保存確認画面の表示' : '保存内容の準備'}に失敗しました（${error?.name || 'Error'}）。保存は実行していません。`, true);
            }
        } finally {
            // この要求が開始した場合だけ保存処理の操作ロックを解除
            if (ownsSaveLock && operationVersion === this.connectionVersion) {
                // 保存処理の操作ロックを解除
                this.saving = false;
                // 成功・部分失敗・例外のすべてで固定表示を終了
                this.saveInProgress = false;
                // 次の編集を許可
                this.busy = false;
            }
        }
    }
    // 一括結果を確定してから次の要求へ進む
    async saveClassifyRows(objectName, changes, operationVersion) {
        // 内部の保存処理を直接呼ばれた場合も標準権限を必須にする
        if (!this.canEditClassifyData) { throw new Error('データ分類の変更には「データ分類の変更」または「オブジェクトのカスタマイズ」権限が必要です。'); }
        // 保存操作全体の開始時だけ実接続先をサーバーで確認
        const authenticated = await this.refreshApiAuthentication();
        // 認証確認中の離脱・再接続後に一つ目の保存を送らない
        if (!this.componentConnected || operationVersion !== this.connectionVersion) { return; }
        // 確認できなければ一つ目のバッチも送信しない
        if (!authenticated) { throw new Error('保存開始前のAPI接続・接続先組織を確認できませんでした。保存は実行していません。認証状態と接続設定を確認してください。'); }
        // API上限に合わせた保存単位を作成
        const batches = classifyBatches(changes);
        // 確認済み項目数だけを進捗として表示
        let processed = 0;
        // 前の一括保存の確認後に次へ進み、同時送信しない
        await batches.reduce((pending, batch) => pending.then(async () => {
            // 画面離脱後は未送信のバッチを開始しない
            if (!this.componentConnected || operationVersion !== this.connectionVersion) { return; }
            // 未確定の項目を処理済みに数えない
            this.setClassifyNotice(`${processed} / ${changes.length}項目を処理済み…`);
            // 各行の対象・基準値・編集値を同じ要求へまとめる
            const results = await saveClassifyData({ objectName, changesJson: JSON.stringify(batch) });
            // 送信済み要求の応答で新しい画面状態を変更しない
            if (!this.componentConnected || operationVersion !== this.connectionVersion) { return; }
            // 応答順に依存せずAPI名と所有者IDを照合
            const updated = applyClassifyBatch(batch, this.classifyEdits, this.classifyData, results);
            // 表示行を更新する前に成功項目の保存値を揃える
            this.classifyData = updated.classifyData;
            // 編集値と保存値が揃った状態で件数と表示行を一度だけ更新
            this.classifyEdits = updated.edits;
            // 値または入力エラーの変更を保存可否へ反映
            this.refreshClassifySummary();
            // 失敗項目の入力は維持して成否を集計
            this.saveSuccessCount += updated.successCount;
            // 更新拒否と確認不能を失敗件数に含める
            this.saveFailureCount += updated.failureCount;
            // 次の一括要求へ進む前に件数を確定
            processed += batch.length;
        }), Promise.resolve());
    }
    // 非表示行も含む保存失敗の理由を一覧へ公開
    get saveErrors() { return this.isClassify ? classifySaveErrors(this.classifyEdits, this.detail?.fields) : []; }
    // エラーがあるときだけ一覧を表示
    get hasSaveErrors() { return this.saveErrors.length > 0; }
    // 空状態のセルを表示モードの列数へ合わせる
    get fieldColumnCount() { return this.isReference ? 6 : 8; }
    // 分類の取得・保存中だけ見出し右側へ処理中を表示
    get showClassifySpinner() { return this.isClassify && this.busy; }
    // 選択肢と画面見出しで同じモード名を使用
    get modeLabel() { return this.modeOptions.find((option) => option.value === this.mode)?.label || ''; }
    // 読取モードでは編集列を描画しない
    get isReference() { return this.mode === 'reference'; }
    // 空の参照モード分岐を挟まず分類専用UIを描画
    get isClassify() { return !this.isReference; }
    // 分類変更またはカスタマイズの標準実効権限を参照
    get canEditClassifyData() { return hasModifyDataClassification === true || hasCustomizeApplication === true; }
    // 操作中や変更なしの場合は保存を無効化
    get saveDisabled() { return this.apiAuthenticationStatus !== 'AUTHENTICATED' || !this.canEditClassifyData || this.busy || !this.classifyDataReady || !this.changeCount || this.hasInputErrors; }
    // 入力確認が必要な行を常に案内
    get hasInputErrors() { return this.inputErrorCount > 0; }
}
