# オブジェクトエクスプローラー

オブジェクト間の参照関係と項目定義を確認し、データ分類の編集とCSVの入出力を行う。

## デプロイ前の接続設定

導入先で、API名 `InternalSalesforceApi` のローカル外部クライアントアプリケーションと同名のExternal Auth Identity Providerを作成します。スコープは `api refresh_token` です。OAuth認可コードフローを使い、アプリとプロバイダーの両方でPKCEを有効化し、プロバイダーのクライアント認証を `ClientSecretPost` にします。認可・トークンのURLは導入先のMy Domainにある `/services/oauth2/authorize` と `/services/oauth2/token` です。鍵・秘密をプロバイダーに登録し、プロバイダーが表示するコールバックURLをアプリに登録します。

アプリは管理者による事前承認を設定し、必要な利用者を許可します。

## デプロイ

ZIPを展開し、`sfdx-project.json` のある `object-explorer` ディレクトリで実行します。以下はbashまたはzshの例です。変数にはSalesforce CLIで認証済みの導入先aliasを指定します。

```sh
cd object-explorer
TARGET_ORG='導入先のalias'
```

Sandbox・Scratch Orgでは、次のコマンドで検証し、成功したら2つ目のコマンドで反映します。

```sh
sf project deploy start --dry-run --target-org "$TARGET_ORG" --manifest package.xml --test-level RunLocalTests --wait 60
sf project deploy start --target-org "$TARGET_ORG" --manifest package.xml --test-level RunLocalTests --wait 60
```

本番組織・Developer Editionでは、次のコマンドで検証します。成功時に表示された検証ジョブIDを指定すると、同じ検証内容を反映できます。

```sh
sf project deploy validate --target-org "$TARGET_ORG" --manifest package.xml --test-level RunLocalTests --wait 60
VALIDATION_ID='成功した検証ジョブID'
sf project deploy quick --target-org "$TARGET_ORG" --job-id "$VALIDATION_ID" --wait 60
```

## タブと利用権限

アプリケーションマネージャーで対象のLightningアプリを編集し、ナビゲーション項目に「オブジェクトエクスプローラー」を追加します。

- 利用者への設定：`LwcObjectExplorer`。
- 利用条件：取引先・取引先責任者の参照、APIの有効化、データ分類の変更、プリンシパル利用を付与。個別の項目公開範囲は導入先で設定。

## 本人認証

1. ［指定ログイン情報］→［外部ログイン情報］で、名前が `InternalSalesforceApi` の定義を開きます。手動作成する場合は認証プロトコルを OAuth 2.0、フローをブラウザーフローにし、同名の外部認証 ID プロバイダーを指定します。スコープは `api refresh_token`、プリンシパルの ID 種別はユーザーごと、パラメーター名は `SalesforceApiUserPrincipal` にします。配布 ZIP にはこの外部ログイン情報とプリンシパルが含まれています。
2. ［指定ログイン情報］で名前が `InternalSalesforceApi` の指定ログイン情報を作成または編集し、URL に導入先の My Domain URL、外部ログイン情報に手順 3 の定義を指定します。［認証ヘッダーを生成］をオンにし、［HTTP 本文の数式を許可］をオンにします。
3. 権限セット `LwcObjectExplorer` の［外部ログイン情報プリンシパルアクセス］で `InternalSalesforceApi-SalesforceApiUserPrincipal` が有効なことを確認し、利用者に権限セットを割り当てます。
4. 利用者本人で［オブジェクトエクスプローラー］を開き、［認証］が表示されたらクリックしてアクセスを許可します。タブに戻り、オブジェクトの検索欄が表示されることを確認します。
5. アクセストークンの有効期限が切れた後、同じ利用者でオブジェクトエクスプローラーを開き、再ログインせずに項目のデータ分類を取得できることを確認します。
