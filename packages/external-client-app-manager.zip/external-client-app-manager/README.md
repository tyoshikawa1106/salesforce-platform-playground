# 外部クライアントアプリ認証管理

ローカル外部クライアントアプリの鍵・秘密を更新し、旧認証情報を確認・削除する。

## デプロイ前の接続設定

導入先で、API名 `ExternalClientAppManager` のローカル外部クライアントアプリケーションと同名のExternal Auth Identity Providerを作成します。スコープは `api refresh_token openid` です。OAuth認可コードフローを使い、アプリとプロバイダーの両方でPKCEを有効化し、プロバイダーのクライアント認証を `ClientSecretPost` にします。認可・トークンのURLは導入先のMy Domainにある `/services/oauth2/authorize` と `/services/oauth2/token` です。鍵・秘密をプロバイダーに登録し、プロバイダーが表示するコールバックURLをアプリに登録します。

管理用アプリは更新対象と分け、組織設定で「REST APIを使用した外部クライアントアプリケーションのコンシューマーの秘密へのアクセスを許可」を有効にします。

## デプロイ

ZIPを展開し、`sfdx-project.json` のある `external-client-app-manager` ディレクトリで実行します。以下はbashまたはzshの例です。変数にはSalesforce CLIで認証済みの導入先aliasを指定します。

```sh
cd external-client-app-manager
TARGET_ORG='導入先のalias'
```

Sandbox・Scratch Orgでは、次のコマンドで検証し、成功したら2つ目のコマンドで反映します。

```sh
sf project deploy start --dry-run --target-org "$TARGET_ORG" --manifest package.xml --test-level RunLocalTests --wait 60
sf project deploy start --target-org "$TARGET_ORG" --manifest package.xml --test-level RunLocalTests --wait 60
```

本番組織・Developer Editionでは、次のコマンドで検証します。成功時に表示された検証ジョブIDを指定すると、同じ検証内容を反映できます。

```sh
sf project deploy validate --target-org "$TARGET_ORG" --manifest package.xml --test-level RunLocalTests --wait 60
VALIDATION_ID='成功した検証ジョブID'
sf project deploy quick --target-org "$TARGET_ORG" --job-id "$VALIDATION_ID" --wait 60
```

## タブと利用権限

アプリケーションマネージャーで対象のLightningアプリを編集し、ナビゲーション項目に「外部クライアントアプリ認証管理」を追加します。

- 利用者への設定：`LwcExternalClientAppManager`。
- 利用条件：カスタム権限 `ManageExternalClientAppCredentials`、プリンシパル利用とクライアントの秘密を扱う管理権限を付与。

## 本人認証

1. ［指定ログイン情報］→［外部ログイン情報］で、名前が `ExternalClientAppManager` の定義を開きます。手動作成する場合は認証プロトコルを OAuth 2.0、フローをブラウザーフローにし、同名の外部認証 ID プロバイダーを指定します。スコープは `api refresh_token openid`、プリンシパルの ID 種別はユーザーごと、パラメーター名は `ExternalClientAppUserPrincipal` にします。配布 ZIP にはこの外部ログイン情報とプリンシパルが含まれています。
2. ［指定ログイン情報］で名前が `ExternalClientAppManager` の指定ログイン情報を作成または編集し、URL に導入先の My Domain URL、外部ログイン情報に手順 1 の定義を指定します。［認証ヘッダーを生成］をオンにし、［HTTP 本文の数式を許可］をオフにします。
3. 権限セット `LwcExternalClientAppManager` の［外部ログイン情報プリンシパルアクセス］で `ExternalClientAppManager-ExternalClientAppUserPrincipal` が有効なことを確認し、利用者に権限セットを割り当てます。
4. 利用者本人で［外部クライアントアプリ認証管理］を開き、［認証］が表示されたらクリックしてアクセスを許可します。タブに戻り、管理対象アプリの選択欄が表示されることを確認します。
